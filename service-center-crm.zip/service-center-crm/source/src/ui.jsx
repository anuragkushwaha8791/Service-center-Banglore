import React,{useState,useEffect,useRef,useCallback,useSyncExternalStore} from "react";
import {UI,subscribe,getVer,act,host,uiSet} from "./store.js";

const useStore=()=>useSyncExternalStore(subscribe,getVer);

function ThemeBtn(){return <button className="tmb gry" title="Dark / Light mode" aria-label="Dark / Light mode" onClick={()=>act.theme&&act.theme()}>{UI.theme==="dark"?"☀️":"🌙"}</button>}

function Clock(){const [t,setT]=useState(()=>new Date().toLocaleString());useEffect(()=>{const i=setInterval(()=>setT(new Date().toLocaleString()),1000);return()=>clearInterval(i)},[]);return <small id="dt" style={{color:"var(--mut)"}}>{t}</small>}

function Splash(){const [t,setT]=useState(0);useEffect(()=>{const i=setInterval(()=>setT(x=>x+1),1000);return()=>clearInterval(i)},[]);
 const b=UI.boot,name=(UI.shell&&UI.shell.app)||"Service Center";
 return <div id="splash" role="status" aria-live="polite"><div className="sp-in">
  <div className="sp-ring"><i/><i/><b>SC</b></div><h2>{name}</h2><p className="sp-msg">{b.msg}</p><div className="sp-bar"><i/></div>
  {t>=8&&!b.err&&<p className="sp-slow">The connection is slow – still trying. Please check your internet.</p>}
  {(t>=30||b.err)&&<button onClick={()=>location.reload()}>↻ Reload</button>}</div></div>}

function Wheel({steps,center}){const [i,setI]=useState(0),[show,setShow]=useState(true);
 useEffect(()=>{const id=setInterval(()=>setI(x=>(x+1)%Math.max(1,steps.length)),2400);return()=>clearInterval(id)},[steps.length]);
 useEffect(()=>{setShow(false);const id=setTimeout(()=>setShow(true),350);return()=>clearTimeout(id)},[i]);
 const pos=k=>{const r=(-90+k*72)*Math.PI/180;return [50+44*Math.cos(r),50+44*Math.sin(r)]},a=steps[i]||{t:"",d:"",c:"#f59e0b"},[dx,dy]=pos(i);
 return <div className="art"><div className="wheel" id="wheel"><svg viewBox="0 0 100 100"><circle className="wtrack" cx="50" cy="50" r="44"/><circle className="wdot" cx="50" cy="6" r="2.6" style={{cx:dx+"px",cy:dy+"px",fill:a.c}}/></svg>
  {steps.map((s,k)=>{const [x,y]=pos(k);return <div key={k} className={"wnode"+(k===i?" active":"")} style={{left:x+"%",top:y+"%"}}><div className="dot" style={{background:s.c,color:s.c}}/><b>{s.t}</b><span>{s.d}</span></div>})}
  <div className="wcenter"><b>{center}</b></div></div>
  <div id="thought" style={{opacity:show?.9:0}}>{a.t?a.t+" — "+a.d:""}</div></div>}

function Login(){const sh=UI.shell||{steps:[],app:"",sub:"",wheel:""},L=UI.login,[em,setEm]=useState(""),[pw,setPw]=useState("");
 const go=()=>act.login(em.trim(),pw);
 return <div id="login"><div style={{position:"fixed",top:12,right:12,zIndex:5}}><ThemeBtn/></div>
  <Wheel steps={sh.steps} center={sh.wheel}/>
  <div className="lw"><form className="box" onSubmit={e=>{e.preventDefault();go()}}><h1>{sh.app}</h1><div className="sub">{sh.sub}</div>
   <input id="em" type="email" placeholder="Email address" autoComplete="username" value={em} onChange={e=>setEm(e.target.value)}/>
   <input id="pw" type="password" placeholder="Password" autoComplete="current-password" value={pw} onChange={e=>setPw(e.target.value)}/>
   <button type="submit" id="lb" style={{width:"100%",padding:12}} disabled={L.busy}>{L.busy?"Signing in…":"Sign In"}</button>
   <div style={{display:"flex",justifyContent:"space-between",marginTop:8}}><button type="button" className="lnk" id="fp" onClick={()=>act.forgot(em.trim())}>Forgot password?</button><button type="button" className="lnk" id="os" onClick={()=>act.ownerSetup(em.trim(),pw)}>Owner first-time setup</button></div>
   <p id="err" role="alert" style={{color:L.ok?"#16a34a":"#dc2626",fontSize:13,marginTop:8,textAlign:"center"}}>{L.msg}</p></form></div></div>}

function ViewHost(){const ref=useCallback(el=>{host.view=el;if(el){["onclick","onchange","oninput","onkeydown"].forEach(k=>{el[k]=e=>{const h=host.events&&host.events[k];if(h)h(e)}});if(host.onViewReady)host.onViewReady()}},[]);return <div id="view" ref={ref}/>}

function Shell(){const sh=UI.shell,[open,setOpen]=useState(false);if(!sh)return null;
 const go=id=>{act.nav(id);setOpen(false)},it=id=>sh.items.find(x=>x.id===id),Link=({id})=>{const x=it(id);return x?<a className={sh.view===id?"on":""} role="button" tabIndex={0} onClick={()=>go(id)} onKeyDown={e=>{if(e.key==="Enter")go(id)}}>{x.ic} {x.label}</a>:null};
 return <div id="app"><div id="ov" className={open?"":"hide"} style={{position:"fixed",inset:0,background:"rgba(0,0,0,.5)",zIndex:19}} onClick={()=>setOpen(false)}/>
  <div className={"side"+(open?" open":"")} id="side"><div className="logo">{sh.app}</div>
   <Link id="dash"/><div id="locnav">{sh.locs.map(l=><a key={l.id} role="button" tabIndex={0} className={l.on?"on":""} onClick={()=>{act.pickLoc(l.id);setOpen(false)}} onKeyDown={e=>{if(e.key==="Enter"){act.pickLoc(l.id);setOpen(false)}}}>{l.ic} {l.menu} ▾</a>)}</div>
   <Link id="inv"/><Link id="log"/><Link id="usr"/><Link id="set"/><Link id="acc"/>
   <a id="lo" role="button" tabIndex={0} style={{background:"#7f1d1d",color:"#fff",marginTop:14}} onClick={()=>act.logout()}>{sh.out}</a></div>
  <div className="main"><div className="top"><button className="hb" id="hb" aria-label="Menu" onClick={()=>setOpen(true)}>☰</button><h1 id="ttl">{sh.title}</h1>
   {sh.bell>0&&<button id="bell" title="Low stock alerts" onClick={()=>act.bell()}>🔔 <b>{sh.bell}</b></button>}<ThemeBtn/>
   <div style={{textAlign:"right"}}><b id="who" dangerouslySetInnerHTML={{__html:sh.who}}/><br/><Clock/></div></div>
   {UI.warn&&<div id="warn" role="alert">{UI.warn}</div>}<ViewHost/></div></div>}

function Toasts(){return <div className="toasts" aria-live="polite">{UI.toasts.map(t=><div key={t.id} className="tst">{t.m}</div>)}</div>}

function Dialog(){const d=UI.dialog,[val,setVal]=useState(""),ref=useRef(null);
 useEffect(()=>{if(d){setVal(d.def||"");const id=setTimeout(()=>{const n=ref.current;if(n){n.focus();if(n.select)n.select()}},40);return()=>clearTimeout(id)}},[d]);
 useEffect(()=>{if(!d)return;const h=e=>{if(e.key==="Escape"){e.preventDefault();uiSet({dialog:null});d.res(d.type==="confirm"?false:null)}};document.addEventListener("keydown",h);return()=>document.removeEventListener("keydown",h)},[d]);
 if(!d)return null;
 const close=r=>{uiSet({dialog:null});d.res(r)},cancel=()=>close(d.type==="confirm"?false:null);
 return <div className="dlg-back" onMouseDown={e=>{if(e.target===e.currentTarget)cancel()}}>
  <div className="dlg" role="dialog" aria-modal="true"><p className="dlg-msg">{d.msg}</p>
   {d.type==="prompt"&&<input ref={ref} type={d.num?"number":"text"} step="any" value={val} onChange={e=>setVal(e.target.value)} onKeyDown={e=>{if(e.key==="Enter")close(val)}}/>}
   <div className="dlg-act"><button type="button" className="gry" onClick={cancel}>Cancel</button><button type="button" ref={d.type==="confirm"?ref:null} className={d.danger?"red":""} onClick={()=>close(d.type==="prompt"?val:true)}>{d.ok}</button></div></div></div>}

export function App(){useStore();const s=UI.boot.state;
 return <>{(s==="loading"||s==="booting")&&<Splash/>}{s==="out"&&<Login/>}{s==="in"&&<Shell/>}<div id="modal" className="hide"/><Toasts/><Dialog/></>}
