
import {UI,uiSet,act,host,toastMsg,askConfirm,askPrompt} from "./store.js";
// Firebase libraries are loaded in parallel, after the splash screen is already on screen (pinned version)
const FBV="10.13.2",FBU=n=>`https://www.gstatic.com/firebasejs/${FBV}/firebase-${n}.js`;
const [FA,FU,FS]=await Promise.all([import(FBU("app")),import(FBU("auth")),import(FBU("firestore"))]);
const {initializeApp,deleteApp}=FA;
const {getAuth,signInWithEmailAndPassword,signOut,onAuthStateChanged,createUserWithEmailAndPassword,updatePassword,sendPasswordResetEmail}=FU;
const {getFirestore,initializeFirestore,persistentLocalCache,persistentMultipleTabManager,collection,doc,getDoc,getDocs,setDoc,updateDoc,deleteDoc,query,where,limit,orderBy,startAfter,writeBatch,serverTimestamp,Timestamp,getCountFromServer,deleteField,increment,onSnapshot}=FS;
uiSet({boot:{state:"loading",msg:"Connecting to the server…"}});

const firebaseConfig = {
  apiKey: "AIzaSyCKtdot0OTYMzuIlHkkvP2o-8KQ-36-HZQ",
  authDomain: "for-blr-team.firebaseapp.com",
  projectId: "for-blr-team",
  storageBucket: "for-blr-team.firebasestorage.app",
  messagingSenderId: "1096056026396",
  appId: "1:1096056026396:web:eb48c9fcc97b889aa8b6d9",
  measurementId: "G-10R8BFR43M"
};
const APPCHECK_SITE_KEY=(window.CRM_CONFIG&&window.CRM_CONFIG.appCheckSiteKey)||"";   // optional: set it at the top of index.html (see SECURITY_CHECKLIST.txt)
const app=initializeApp(firebaseConfig);let APPCHECK=null;
if(APPCHECK_SITE_KEY){try{APPCHECK=await import("https://www.gstatic.com/firebasejs/10.13.2/firebase-app-check.js");APPCHECK.initializeAppCheck(app,{provider:new APPCHECK.ReCaptchaV3Provider(APPCHECK_SITE_KEY),isTokenAutoRefreshEnabled:true})}catch(e){console.error("App Check failed",e)}}
const auth=getAuth(app);
let db;try{db=initializeFirestore(app,{localCache:persistentLocalCache({tabManager:persistentMultipleTabManager()}),experimentalAutoDetectLongPolling:true})}catch(_){db=getFirestore(app)}
const OWNER="operations194@mooving.com",FETCH=200,LOGMAX=50,PAL=["#2f6fb0","#f59e0b","#16a34a","#dc2626","#7c3aed","#0891b2","#db2777","#64748b"];
const FAIL=/non[- ]?repairable|scrap|dead|not ok|fail/i,OK=/^ok$|repaired|no issue found/i;

const BI=["Cell Unbalance Protection ON","Latch Protection ON","Charge UTP","CAN Data Issue","IoT Not Working","FET Failure - BMS","Temperature Sensor Fault","CAN Wire Damage","Battery Damage / Physical Issue","BUID Mismatch","PCB Over Temperature Fault","CAN Pin Backout","Water Ingress","Cell Dead","Cell Series Dead","LED Not Working","Fuse Burnt","Other Issue"];
const BA=["Balancing Done","Released Through Lime App","Fixed Loose Connection","CAN Pin Fixed / IoT Reset","IoT Reset / IoT Replaced","Battery Pack Reset / BMS Replaced","Connector Removed and Reconnected","Wire Soldered","RTB","Fixed Through PCAN or BLE App","Checked Harness Connection and Fixed","CAN Pin Fixed Using Aligner Key","Balancing Required Twice & CDC Twice","Connection Checked / LED Replaced","Fuse Replaced","Other (Specify)"];
const CI=["Charger AC Plug Burnt","Charger AC Plug Damaged","Charger IC Burnt","Charger MOSFET Burnt","Connector Voltage Not Showing","Fan Not Working","FW Updated (Mapping)","LED Not Working","No Power Supply Available","SB-75 Connector Damaged","Slave Card CAN IC Burnt","Slave Card Communication IC Burnt","SBS Damaged","CAN Pin Wire Added","Other"];
const LM=["SB75 Connector", "Gold Pin", "Silver Pin", "Thimble", "SB 75 Connector Sleeve", "CAN Connector Male", "DC Fan Screw", "T Handle", "T Handle Screw + Nut + Washer", "Pressure Valve", "AC Input Connector", "AC Input Connector Cover (Sub Assembly)", "Cable Tie 150MM", "Fan Grill (3 inch)", "DC Fan 12V (Length + Width 3 inch)", "Grommet", "Base Plate Screw", "FFC Cable (10 Pin)", "Thermal Pad (Q8, Q9, D1, Q1, Q2, BR1, D13, D14, D15, D16)", "Fiber Glass Sleeve", "Power Board Screw", "10 mm Thermal Pad", "Charger Handle", "DC Output Cable (Sub Assembly)", "Golden Power Thimble (Black + Red Sleeve)", "Daughter Board", "Daughter Board Casing Top"],LE=["SL - SMD Diode — D17, D18", "Capacitor 100V 470uF — C25, C50", "Capacitor 450V 10uF — C17", "Bridge Rectifier — BR1", "MOSFET 60R080P7 — Q1, Q2, Q8, Q9", "Capacitor 470uF (M) 450V — C7", "Diode 2409 / D106506PQG2 — D1", "Viper IC 5QR4770AZ / H2306153P / 7A2331767G2 — U1", "SMD Diode — D13, D14, D15, D16", "IC D12001 — U6", "IC 3PG501 / H2350 / M27 / PF249289L55 — U10", "IC 2EDL23N06PJ / H2429 / L3D / 6A301245A02 — U2", "SMD Resistor 4R70 5.6m — R32, R35", "SMD Resistor 22R0 22k — R31, R34", "SMD Diode GS1M — D3, D9, D19, D21, D24, D25", "SMD 214.V — R9, R46", "50 2345 — NTC1", "IC 4UA5 — U5", "Transistor 2F — Q8", "SMD Resistor 10k — R37, R36", "SMD Fuse R010 — SH2, SH3", "IC — U8", "2H4 / K7 — Q11", "Fuse — F1", "Capacitor 4.7uF SMD — C60", "Resistance — R47", "Driver Transformer — T1", "Main Transformer — T2", "Line Filter — L1", "Line Filter — L3", "SMD Diode US1M 0.465 — D4, D5, D6, D20", "SMD Resistor 1000 / 100k — R72, R73, R106, R107", "SMD Resistor 22R0 22.3k — R31, R34, R82", "SMD Resistor 4.6k — R30, R34, R49", "SMD Diode 350+ Value — D2", "S20 / K275 — MOV", "Box Type Capacitor 22N J 700VAC S8 — C10, C16, C24, C42", "Relay 12V — K1", "Transistor KL4 — Q1, Q5, Q3, Q7, Q6, Q9", "Transistor AVW / 13 — U4, U10", "Capacitor SMD 1nF — C29, C30, C31, C32", "Diode SMD Value 0.660 — Z1, D27"];
// [key,label,type,default options]; no field is mandatory
const BASE={
 battery:{title:"Battery Repair",col:"battery_repairs",stat:"repairStatus",fields:[
  ["ticketDate","Date","date"],["repairLocation","Repair Location","sel",[]],["batteryMake","Battery Pack Make & Model","sel",["Inverted","Trontek"]],["batterySrNo","Battery Sr. No.","text"],["iotImei","IoT IMEI No.","text"],
  ["physicalCondition","Physical Condition","sel",["OK","Not OK"]],["canResistance","CAN Resistance","text"],["connectorVoltage","Connector Voltage","text"],["soc","SOC","text"],
  ["iotLastSync","IoT Last Sync","datetime-local"],["gpsTime","GPS Time Stamp","datetime-local"],["iotStatus","IoT Status","sel",["Working","Not Working"]],
  ["iotFirmware","IoT Firmware","text"],["bmsFirmware","BMS Firmware","text"],["chargerAuth","Charger Auth","sel",["On","Off"]],["configVersion","Configuration Version","text"],
  ["iotNotWorking","IoT Not Working (Details)","text"],["reportedIssue","Reported Issue","sel",BI],["actionTaken","Action Taken","sel",BA],
  ["repairStatus","Repair Status","sel",["OK","Not OK","Non-Repairable","Scrap"]],["pdiStatus","PDI (Pass/Fail)","sel",["Pass","Fail"]]]},
 charger:{title:"Charger / BSS Repair",col:"charger_repairs",stat:"repairStatus",fields:[
  ["openDate","Ticket Open Date","date"],["closeDate","Ticket Closing Date","date"],["bssType","BSS Type","sel",["V1","V2"]],["repairLocation","Repair Location","sel",["Bangalore CSC"]],
  ["assetType","Type of Asset Repaired","sel",["BSS Master Card","BSS Other Part","Charger","Slave Card"]],["assetSrNo","Asset Sr. No. (Slave or Charger)","text"],
  ["reportedIssue","Reported Issue","sel",CI],
  ["assetModel","Charger / Slave Card Make & Model","sel",["BSS Master Card for Repair","Drone Power 16A","LGDT BSS Charger","Santla BSS Charger","Slave Card","Controller IC","BSS Harness"]],
  ["repairStatus","Repair Status","sel",["No Issue Found (OK)","Non-Repairable (Dead)","Open-RTB for Plant Repair","Repaired","Hold for Part"]],
  ["repairedBy","Repaired By","sel",["Balu","Shakti","Other"]],["component1","Component Used 01","text"],["component2","Component Used 02","text"],["remarks","Remarks","area"]]},
 lucknow:{title:"Lucknow Charger Repair",col:"lucknow_charger_repairs",stat:"repairStatus",fields:[
  ["repairDate","Date","date"],["repairLocation","Repair Location","sel",["Lucknow"]],["chargerType","Charger Type","sel",["Vecmocon","Livguard"]],["serialNo","Serial Number","text"],
  ["reportedIssue","Reported Issue","sel",["Mechanical","Electrical Issue"]],["mechParts","Mechanical Parts Used","multi",LM],["elecParts","Electrical Parts Used (Part — Sub Part)","multi",LE],
  ["repairStatus","Repair Status","sel",["Charger Repaired","Hold for Part","Dead"]],["remarks","Remarks","area"]]}
};
/* ===== LOCATIONS & MODULES (dynamic) ===== */
const T0={batt:BASE.battery.fields,blr:BASE.charger.fields,lko:BASE.lucknow.fields};
const DEFLOCS=[
 {id:"bangalore",name:"Bangalore CSC",menu:"Bangalore Service",ic:"🏢",tpl:"blr",sys:1},
 {id:"ghaziabad",name:"Ghaziabad Warehouse Repairing Center",menu:"Ghaziabad Warehouse Repairing Center",ic:"🏬",tpl:"lko",sys:1},
 {id:"lucknow",name:"Lucknow",menu:"Lucknow",ic:"🏭",tpl:"lko",sys:1}];
const LEG={bangalore:{b:"battery",c:"charger",bcol:"battery_repairs",ccol:"charger_repairs"},
 ghaziabad:{b:"gzBattery",c:"gzCharger",bcol:"ghaziabad_battery_repairs",ccol:"ghaziabad_charger_repairs"},
 lucknow:{b:"lkBattery",c:"lucknow",bcol:"lucknow_battery_repairs",ccol:"lucknow_charger_repairs"}};
let LOCS=DEFLOCS.map(l=>({...l,mods:[]}));
const locOpts=()=>[...LOCS.map(l=>l.name),"Other"];
const locName=id=>LOCS.find(l=>l.id===id)?.name||"",locMenu=id=>LOCS.find(l=>l.id===id)?.menu||"";
const ft=k=>locMenu(BASE[k].loc)+" · "+BASE[k].title;
const isBat=k=>BASE[k].fields.some(f=>f[0]==="batterySrNo");
const hasParts=k=>BASE[k].fields.some(f=>f[0]==="mechParts");
const EF=()=>({q:"",u:"",from:"",to:"",col:"",val:""});
const S={},FL={},DIM={},SHOW={},DALL={},WIN={};
const WINS=[[0,"All time (all old entries)"],[365,"Last 12 months"],[180,"Last 6 months"],[90,"Last 90 days"],[30,"Last 30 days"]];
const readWin=k=>{let r=0;try{const v=localStorage.getItem("win_"+k);if(v!==null&&WINS.some(w=>w[0]===+v))r=+v}catch(_){}return r};
function regMods(){
 for(const l of LOCS){const g=LEG[l.id]||{b:l.id+"_b",c:l.id+"_c",bcol:l.id+"_battery_repairs",ccol:l.id+"_charger_repairs"},lko=l.tpl==="lko";
  BASE[g.b]={title:"Battery Repair",t0:"Battery Repair",col:g.bcol,stat:"repairStatus",fields:T0.batt.map(f=>[...f]),cfg:"battery",loc:l.id,ic:"🔋"};
  BASE[g.c]={title:lko?"Charger Repair":"Charger / BSS Repair",t0:lko?"Charger Repair":"Charger / BSS Repair",col:g.ccol,stat:"repairStatus",fields:(lko?T0.lko:T0.blr).map(f=>[...f]),cfg:lko?"lucknow":"charger",loc:l.id,ic:"⚡"};
  l.mods=[g.b,g.c]}
 const keep=new Set(LOCS.flatMap(l=>l.mods));for(const k of Object.keys(BASE))if(!keep.has(k))delete BASE[k];
 for(const k in BASE){BASE[k].title=BR.mod[k]||DEF_BR.mod[k]||BASE[k].t0;
  if(!S[k]){S[k]={rows:[],cur:null,more:false,loaded:false};FL[k]=EF();DIM[k]="reportedIssue";SHOW[k]=5;DALL[k]=false;WIN[k]=readWin(k)}}}
function applyLocs(list){const m=new Map(DEFLOCS.map(l=>[l.id,{...l}]));
 (Array.isArray(list)?list:[]).forEach(x=>{if(!x||typeof x.id!=="string"||!/^[a-z0-9]{2,14}$/.test(x.id))return;
  const d=m.get(x.id),nm=String(x.name||x.menu||"").trim().slice(0,60),mn=String(x.menu||nm).trim().slice(0,60);
  if(d){if(nm){d.name=nm;d.menu=mn}}else if(nm)m.set(x.id,{id:x.id,name:nm,menu:mn,ic:"📍",tpl:x.tpl==="blr"?"blr":"lko"})});
 LOCS=[...m.values()].map(l=>({...l,mods:[]}));regMods()}
const wq=k=>{const d=WIN[k];return d>0?[where("createdAt",">=",Timestamp.fromDate(new Date(Date.now()-d*864e5))),orderBy("createdAt","desc")]:[]};
const DEF_BR={app:"Service Center Bangalore",sub:"Battery & Charger Repair Operations",wheel:"Service Center & Repair Cycle",dashTitle:"CRM Dashboard",
 nav:{dash:"Dashboard",inv:"Inventory",battery:"Battery Repair",charger:"Charger / BSS Repair",lucknow:"Lucknow Charger Repair",log:"Activity Log",usr:"Users",set:"Admin Settings",acc:"My Account",out:"Sign Out"},
 mod:{battery:"Battery Repair",charger:"Charger / BSS Repair",lucknow:"Lucknow Charger Repair"},
 steps:[{t:"Ticket Logged",d:"Asset received at Bangalore CSC"},{t:"Diagnosis",d:"Physical & electrical checks"},{t:"Repairing",d:"Component / BMS / IoT repair"},{t:"PDI Testing",d:"Pass / Fail verification"},{t:"Dispatched",d:"Repaired asset ready & closed"}],fl:{}};
let BR=JSON.parse(JSON.stringify(DEF_BR));
regMods();
function mergeBR(s){const b=JSON.parse(JSON.stringify(DEF_BR));s=s||{};const ok=v=>typeof v==="string"&&v.trim();
 for(const k of["app","sub","wheel","dashTitle"])if(ok(s[k]))b[k]=s[k].trim().slice(0,80);
 for(const g of["nav","mod"])for(const k in b[g])if(ok(s[g]?.[k]))b[g][k]=s[g][k].trim().slice(0,60);
 (Array.isArray(s.steps)?s.steps:[]).forEach((x,i)=>{if(b.steps[i]&&x){if(ok(x.t))b.steps[i].t=x.t.trim().slice(0,40);if(ok(x.d))b.steps[i].d=x.d.trim().slice(0,80)}});
 b.fl=s.fl&&typeof s.fl==="object"?s.fl:{};return b}
let me=null,users=[],logs=[],cfg={opts:{},custom:{},perm:{},meta:{}},view="dash",dm="battery",stm="battery",dLog=5,lLog=5,lastLoad=0,refT=null;
const $=s=>document.querySelector(s);
const isOwner=()=>me?.role==="owner",isAdmin=()=>!!me&&(me.role==="owner"||me.role==="admin"),can=p=>isAdmin()||cfg.perm[p]!==false;
const esc=v=>String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const toast=toastMsg;
const nid=()=>String(9e12-Date.now()).padStart(13,"0")+Math.random().toString(36).slice(2,8);
const isOther=v=>/^other/i.test(v||"");
const tsd=t=>t?.toDate?t.toDate():(t instanceof Date?t:null);
const tm=t=>{const d=tsd(t);return d?d.toLocaleString():"…"};
const today=()=>{const d=new Date();return new Date(d-d.getTimezoneOffset()*6e4).toISOString().slice(0,10)};
const asArr=v=>Array.isArray(v)?v:(v?[v]:[]);
const withTO=(p,ms=20000)=>Promise.race([p,new Promise((_,r)=>setTimeout(()=>r({code:"timeout",message:"Save is taking long (slow internet). Press Save again - the same entry will not be duplicated."}),ms))]);
const ymd=p=>p.ticketDate||p.openDate||p.repairDate||(tsd(p.createdAt)?new Date(tsd(p.createdAt)-tsd(p.createdAt).getTimezoneOffset()*6e4).toISOString().slice(0,10):today());
const pct=(a,b)=>b?(a/b*100).toFixed(1):"0.0";
const isFail=p=>FAIL.test(p.repairStatus||"")||FAIL.test(p.pdiStatus||"");
const isOk=p=>!isFail(p)&&OK.test(p.repairStatus||"");
const ck=k=>"L_"+k;
const customOf=k=>{const a=cfg.custom[ck(k)],b=cfg.custom[BASE[k].cfg||k];return Array.isArray(a)?a:(Array.isArray(b)?b:[])};
const hiddenOf=k=>Array.isArray(cfg.custom["H_"+k])?cfg.custom["H_"+k]:[];
const lbl=(k,f)=>BR.fl?.[ck(k)]?.[f[0]]||BR.fl?.[BASE[k].cfg||k]?.[f[0]]||f[1];
const allBase=k=>BASE[k].fields.map(f=>[f[0],lbl(k,f),...f.slice(2)]);
const fieldsOf=k=>{const hid=hiddenOf(k);return [...allBase(k).filter(f=>!hid.includes(f[0])),...customOf(k).map(x=>[x.key,x.label,x.type==="dropdown"?"sel":x.type,[]])]};
const optsOf=(k,f)=>{if(f==="repairLocation")return locOpts();const lo=cfg.opts[ck(k)]?.[f];if(lo)return lo;const c=BASE[k].cfg||k,v=cfg.opts[c]?.[f];if(v)return v;return BASE[k].fields.find(x=>x[0]===f)?.[3]||[]};
const cell=(k,p,[key,,t])=>{let v=p[key]??"";if(Array.isArray(v))return v.map(x=>x+((p.partQty&&p.partQty[x]>1)?" ×"+p.partQty[x]:"")).join(", ");if(t==="sel"&&isOther(v)&&p[key+"Other"])v=v+": "+p[key+"Other"];if(t==="datetime-local")v=String(v).replace("T"," ");return v};
const roleBadge=r=>r==="user"?"":`<span class="badge ${r}">${r}</span>`;
const curMod=()=>BASE[view]?view:dm;
/* ===== ACCESS CONTROL (assigned per user by Admin) + pager + theme ===== */
const PGI=n=>n<15?10:20;           // list size grows 5 -> +10 -> +20 -> +20 ...
let PG={};const pgN=k=>PG[k]||5;
const pgMore=(k,total)=>{const n=pgN(k);return total>n?`<div class="row" style="margin-top:10px"><button class="gry" data-a="pgm" data-i="${k}">Load More (+${PGI(n)})</button><small style="color:var(--mut)">Showing ${Math.min(n,total)} of ${total}</small></div>`:""};
/* effective access of a user: custom "acc" (set by Admin) or the old default (own location + User Permissions) */
const accOf=u=>{const a=u&&u.acc;
 if(a&&typeof a==="object")return {locs:Array.isArray(a.locs)?a.locs:[],cols:a.cols&&typeof a.cols==="object"?a.cols:{},inv:a.inv&&typeof a.inv==="object"?a.inv:{},flags:Array.isArray(a.flags)?a.flags:[],setKeys:Array.isArray(a.setKeys)?a.setKeys:[],custom:true};
 const L=LOCS.find(l=>l.id===u?.location),cols={},inv={},P=cfg.perm||{};
 if(L){for(const k of L.mods)cols[BASE[k].col]=["v",...(P.userAdd!==false?["a"]:[]),...(P.userEdit!==false?["e"]:[]),...(P.userExport!==false?["x"]:[])];inv[L.id]=["v"]}
 return {locs:L?[L.id]:[],cols,inv,flags:P.userLog!==false?["log"]:[],setKeys:[],custom:false}};
const canMod=(k,p)=>!!me&&!!BASE[k]&&(isAdmin()||(accOf(me).cols[BASE[k].col]||[]).includes(p));
const canLoc=l=>isAdmin()||(!!me&&accOf(me).locs.includes(l));
const visLocs=()=>LOCS.filter(l=>isAdmin()||(!!me&&l.mods.some(k=>canMod(k,"v"))));
const invCan=(l,p)=>isAdmin()||(!!me&&(accOf(me).inv[l]||[]).includes(p));
const invLocs=()=>LOCS.filter(l=>invCan(l.id,"v"));
const canLog=()=>isAdmin()||(!!me&&accOf(me).flags.includes("log"));
const canSet=k=>isAdmin()||(!!me&&accOf(me).setKeys.includes("L_"+k));
const hasSetup=()=>isAdmin()||(!!me&&accOf(me).setKeys.length>0);
const defMod=()=>{const pref=LOCS.find(l=>l.id===me?.location),order=pref?[pref,...visLocs().filter(l=>l!==pref)]:visLocs();for(const l of order){const m=l.mods.find(k=>canMod(k,"v"));if(m)return m}return null};
/* theme (dark / light) */
let theme="light";try{theme=localStorage.getItem("theme")==="dark"?"dark":"light"}catch(_){}
const applyTheme=t=>{theme=t;document.documentElement.dataset.theme=t;uiSet({theme:t})};
applyTheme(theme);act.theme=()=>{const n=theme==="dark"?"light":"dark";try{localStorage.setItem("theme",n)}catch(_){}applyTheme(n)};

function fail(e){console.error(e);if(e&&e.code==="permission-denied")uiSet({warn:"Permission denied. Either the Firestore Rules have not been published, or your account does not have permission for this action."});toast("Error: "+((e&&(e.code||e.message))||"unknown"))}

/* ===== ACTIVITY LOG (loaded 5 -> +10 -> +20 at a time; entries older than 40 days are deleted automatically) ===== */
const LOGDAYS=40;let logCur=null,logHas=false,logBusy=false;
async function log(action,detail){if(!me)return;const id=nid(),e={id,uid:me.uid,name:me.name,role:me.role,action,detail:String(detail||"").slice(0,300),ts:new Date()};
 logs.unshift(e);if(view==="dash"||view==="log")render();
 try{const {id:_,...rest}=e;await setDoc(doc(db,"logs",id),{...rest,ts:serverTimestamp()})}catch(_){}}
async function loadLogs(more,quiet){if(!me||logBusy)return;logBusy=true;const n=more?PGI(logs.length):5;
 try{const base=isAdmin()?[collection(db,"logs")]:[collection(db,"logs"),where("uid","==",me.uid)];
  const qs=await getDocs(query(...base,...(more&&logCur?[startAfter(logCur)]:[]),limit(n)));
  const arr=qs.docs.map(d=>({id:d.id,...d.data()}));
  if(more){const ids=new Set(logs.map(x=>x.id));logs=[...logs,...arr.filter(x=>!ids.has(x.id))]}else logs=arr;
  logCur=qs.docs[qs.docs.length-1]||logCur;logHas=qs.docs.length===n}
 catch(e){if(!quiet)fail(e)}finally{logBusy=false}
 if(!quiet)render()}
/* runs for Admin/Owner at most once per 12 hours (free plan has no server timer, so a signed-in admin does the cleaning) */
async function cleanOldLogs(){if(!isAdmin())return;const last=+cfg.meta?.lastLogClean||0;if(Date.now()-last<12*36e5)return;
 try{const cut=Timestamp.fromDate(new Date(Date.now()-LOGDAYS*864e5));
  for(let i=0;i<3;i++){const qs=await getDocs(query(collection(db,"logs"),where("ts","<",cut),limit(400)));if(!qs.docs.length)break;
   const b=writeBatch(db);qs.docs.forEach(d=>b.delete(d.ref));await b.commit();if(qs.docs.length<400)break}
  await setDoc(doc(db,"config","meta"),{lastLogClean:Date.now()},{merge:true});cfg.meta={...(cfg.meta||{}),lastLogClean:Date.now()}}catch(_){}}
const actTable=(l,btn)=>`<div class="tw"><table><thead><tr><th>Time</th><th>User</th><th>Action</th><th>Detail</th></tr></thead><tbody>${l.map(x=>`<tr><td>${tm(x.ts)}</td><td>${esc(x.name)} ${roleBadge(x.role)}</td><td>${esc(x.action)}</td><td class="w">${esc(x.detail)}</td></tr>`).join("")||"<tr><td colspan=4>No activity yet</td></tr>"}</tbody></table></div>${logHas?`<div class="row" style="margin-top:10px"><button class="gry" data-a="${btn}">Load More (+${PGI(l.length)})</button><small style="color:var(--mut)">Showing ${l.length}</small></div>`:""}`;

/* login animation */
const ST=[{t:"Ticket Logged",d:"Asset received at Bangalore CSC",c:"#f59e0b"},{t:"Diagnosis",d:"Physical & electrical checks",c:"#7dd3fc"},{t:"Repairing",d:"Component / BMS / IoT repair",c:"#4ade80"},{t:"PDI Testing",d:"Pass / Fail verification",c:"#c4b5fd"},{t:"Dispatched",d:"Repaired asset ready & closed",c:"#fb7185"}];
const NAVIC={dash:"📊",inv:"📦",log:"📜",usr:"👥",set:"⚙️",acc:"👤"};
let lastShell="";
function shellState(){const au=!!me;
 return {app:BR.app,sub:BR.sub,wheel:BR.wheel,out:BR.nav.out,steps:ST.map(x=>({t:x.t,d:x.d,c:x.c})),view,
  who:au?`${esc(me.name)} ${roleBadge(me.role)}`:"",title:au?ttlOf(view):"",
  items:au?["dash","inv","log","usr","set","acc"].filter(id=>id==="log"?canLog():id==="usr"?isAdmin():id==="set"?hasSetup():true).map(id=>({id,ic:NAVIC[id],label:BR.nav[id]||""})):[],
  locs:au?visLocs().map(l=>({id:l.id,ic:l.ic,menu:l.menu,on:BASE[view]?.loc===l.id})):[],
  bell:au?lowList().length:0}}
function publish(){const j=JSON.stringify(shellState());if(j!==lastShell){lastShell=j;uiSet({shell:JSON.parse(j)})}}
function applyBrand(){document.title=BR.app;
 for(const k in BASE)BASE[k].title=BR.mod[k]||DEF_BR.mod[k]||BASE[k].t0;
 ST.forEach((x,i)=>{if(BR.steps[i]){x.t=BR.steps[i].t;x.d=BR.steps[i].d}});publish()}
try{const c=localStorage.getItem("brand");if(c)BR=mergeBR(JSON.parse(c))}catch(_){}
applyBrand();

const errMsg=e=>({"auth/invalid-credential":"Incorrect email or password.","auth/wrong-password":"Incorrect password.","auth/user-not-found":"No account exists for this email.","auth/invalid-email":"Please enter a valid email address.","auth/too-many-requests":"Too many attempts. Please try again later.","auth/network-request-failed":"Network error. Please check your connection.","auth/operation-not-allowed":"Email/Password sign-in is disabled. Enable it in Firebase Console → Authentication → Sign-in method.","auth/email-already-in-use":"This account already exists. Please sign in or use Forgot password.","auth/requires-recent-login":"Please sign out and sign in again, then retry."}[e.code]||("Error ["+(e.code||"")+"]: "+e.message));
const setLogin=(msg,ok=false,busy=false)=>uiSet({login:{msg,ok,busy}});
act.login=async(email,pw)=>{if(!email||!pw)return setLogin("Please enter your email and password.");setLogin("",false,true);try{await signInWithEmailAndPassword(auth,email,pw)}catch(e){setLogin(errMsg(e))}};
act.forgot=async email=>{if(!email)return setLogin("Please enter your email first.");try{await sendPasswordResetEmail(auth,email);setLogin("Password reset email sent. Please check your inbox and spam folder.",true)}catch(e){setLogin(errMsg(e))}};
act.ownerSetup=async(email,pw)=>{if(email.toLowerCase()!==OWNER)return setLogin("First-time setup is available only for the owner email.");if(pw.length<6)return setLogin("Enter a new password (minimum 6 characters).");try{setLogin("",false,true);await createUserWithEmailAndPassword(auth,email,pw)}catch(e){setLogin(errMsg(e))}};
act.logout=async()=>{await log("Signed out");clearInterval(refT);signOut(auth)};

onAuthStateChanged(auth,async u=>{
 me=null;users=[];logs=[];logCur=null;logHas=false;logBusy=false;clearInterval(refT);dtab="loc";ovBusy=false;invStop();SUB.clear();PG={};
 for(const k in S)Object.assign(S[k],{rows:[],cur:null,more:false,loaded:false,full:false,search:null,err:false});
 if(!u){publish();uiSet({boot:{state:"out",msg:""},login:{...UI.login,busy:false}});return}
 uiSet({boot:{state:"booting",msg:"Verifying your account…"}});
 try{
  const ref=doc(db,"users",u.uid),isO=(u.email||"").toLowerCase()===OWNER;
  const cfgP=loadConfig();   // settings are requested at the same moment as the profile (saves one round trip)
  let p=await getDoc(ref).catch(e=>{if(!isO)throw e;return null});
  if(isO&&(!p||!p.exists()||p.data().role!=="owner")){
   uiSet({boot:{state:"booting",msg:"Setting up the owner account…"}});
   await setDoc(ref,{name:(p&&p.exists()&&p.data().name)||"Owner",email:u.email,role:"owner",disabled:false,createdAt:serverTimestamp()},{merge:true});p=await getDoc(ref);await loadConfig()}
  if(!p||!p.exists()){await signOut(auth);setLogin("Your profile was not found. Please ask the Owner/Admin to create your user account.");return}
  if(p.data().disabled){await signOut(auth);setLogin("Access denied. Your account has been disabled.");return}
  me={uid:u.uid,...p.data()};
  uiSet({boot:{state:"booting",msg:"Loading your workspace…"}});
  await cfgP;dm=defMod()||dm;
  // activity log + user list are only needed on their own screens, so they load in the background
  Promise.all([loadLogs(false,true),isAdmin()?getDocs(collection(db,"users")).then(r=>{users=r.docs.map(d=>({id:d.id,...d.data()}))}):null]).then(()=>{if(me)render()}).catch(()=>{});
  setLogin("");uiSet({boot:{state:"in",msg:""}});
  log("Signed in");nav("dash");cleanOldLogs();invLoadAll().then(()=>{if(view==="dash"||view==="inv")render()});refT=setInterval(refreshAll,5*60*60*1000);
 }catch(err){console.error(err);try{await signOut(auth)}catch(_){}setLogin("Database error: "+(err.code==="permission-denied"?"Firestore Rules are not published (permission denied).":err.message))}
});
act.nav=v=>nav(v);act.pickLoc=id=>pickModal(id,"nav");
const ttlOf=v=>BASE[v]?locMenu(BASE[v].loc)+" › "+BASE[v].title:({dash:BR.dashTitle,log:BR.nav.log,usr:BR.nav.usr,set:BR.nav.set,acc:BR.nav.acc,inv:BR.nav.inv})[v]||"";
function nav(v){if(v==="usr"&&!isAdmin())return;if(v==="set"&&!hasSetup())return;if(BASE[v]&&!canMod(v,"v"))return;if(v==="log"&&!canLog())return;view=v;PG={};
 const k=BASE[v]?v:(v==="dash"&&dtab!=="all"?dm:null);if(v==="dash"&&dtab==="all")ovLoad(false);if(v==="inv")invLoadAll().then(()=>{if(view==="inv")render()});if(k&&canMod(k,"v")){if(v==="dash")ensureDash(k);else if(!S[k].loaded)loadMod(k)}animateView();render()}

async function loadConfig(){const ids=[["options","opts"],["fields","custom"],["permissions","perm"],["meta","meta"]];
 const [rs,br,lc]=await Promise.all([Promise.all(ids.map(([id])=>getDoc(doc(db,"config",id)).catch(()=>null))),getDoc(doc(db,"config","branding")).catch(()=>null),getDoc(doc(db,"config","locations")).catch(()=>null)]);
 ids.forEach(([id,key],i)=>{cfg[key]=rs[i]&&rs[i].exists()?rs[i].data():{}});
 if(br&&br.exists()){BR=mergeBR(br.data());try{localStorage.setItem("brand",JSON.stringify(br.data()))}catch(_){}applyBrand()}
 applyLocs(lc&&lc.exists()&&lc.data().list?lc.data().list:[])}
// everything the first screen needs is requested at the same time (one round trip instead of many)
async function loadBase(){try{await Promise.all([loadConfig(),loadLogs(false,true),isAdmin()?getDocs(collection(db,"users")).then(r=>{users=r.docs.map(d=>({id:d.id,...d.data()}))}):null]);lastLoad=Date.now()}catch(e){fail(e)}}
async function loadMod(k,more,n){if(!canMod(k,"v"))return;const s=S[k],size=n||(more?40:Math.min(Math.max(s.rows.length,5),FETCH));
 try{const qs=await getDocs(query(collection(db,BASE[k].col),...wq(k),...(more&&s.cur?[startAfter(s.cur)]:[]),limit(size)));
  const rows=qs.docs.map(d=>({id:d.id,...d.data()}));s.rows=more?[...s.rows,...rows]:rows;s.cur=qs.docs[qs.docs.length-1]||s.cur;s.more=qs.docs.length===size;s.loaded=true;s.err=false;if(size>=FETCH)s.full=true;lastLoad=Date.now();if(UI.warn)uiSet({warn:""})}catch(e){s.err=true;fail(e)}
 render()}
function ensureDash(k){const s=S[k];if(!s.loaded)loadMod(k,false,FETCH);else if(!s.full&&s.more)loadMod(k,true,FETCH)}
async function refreshAll(){if(!me||document.hidden)return;await loadBase();const ks=Object.keys(S).filter(k=>S[k].loaded);for(const k of ks)await loadMod(k);await invLoadAll();render()}

function buildLocNav(){publish()}
function pickModal(lid,ctx){const L=LOCS.find(x=>x.id===lid);if(!L||!canLoc(lid))return;const m=$("#modal"),cur=ctx==="dash"?dm:view;

 m.innerHTML=`<div class="box" style="width:420px"><h2 style="margin-bottom:6px;color:var(--acc)">${L.ic} ${esc(L.menu)}</h2><p class="note">${ctx==="dash"?"Select which data to show on the dashboard.":"Select what you want to open."}</p>
 ${L.mods.filter(k=>canMod(k,"v")).map(k=>`<button data-pk="${k}" class="${cur===k?"":"gry"}" style="width:100%;padding:16px;margin-bottom:10px;font-size:15px;text-align:left">${BASE[k].ic} ${esc(BASE[k].title)}</button>`).join("")}
 <button class="lnk" id="pkc" style="width:100%">Cancel</button></div>`;
 m.onchange=null;m.oninput=null;m.classList.remove("hide");
 m.querySelectorAll("[data-pk]").forEach(b=>b.onclick=()=>{m.classList.add("hide");if(ctx==="dash"){dm=b.dataset.pk;nav("dash")}else nav(b.dataset.pk)});
 $("#pkc").onclick=()=>m.classList.add("hide")}

/* analytics helpers */
function applyF(k,rows,withQ){const f=FL[k],ql=f.q.toLowerCase();
 return rows.filter(p=>{if(withQ&&ql&&!JSON.stringify(p).toLowerCase().includes(ql))return false;if(f.u&&p.createdBy!==f.u)return false;
  const d=ymd(p);if(f.from&&d<f.from)return false;if(f.to&&d>f.to)return false;if(f.col&&f.val&&!asArr(p[f.col]).includes(f.val))return false;return true})}
function group(rows,fn){const m=new Map();rows.forEach(p=>{let r=fn(p);r=Array.isArray(r)?r:[r];if(!r.length)r=[""];const d=ymd(p),bad=isFail(p),good=!bad&&isOk(p);
 new Set(r.map(x=>x||"(blank)")).forEach(key=>{let g=m.get(key);if(!g){g={n:0,f:0,o:0,last:""};m.set(key,g)}g.n++;if(bad)g.f++;else if(good)g.o++;if(d>g.last)g.last=d})});
 return [...m].map(([k,g])=>({k,...g})).sort((a,b)=>b.n-a.n)}
const dimVal=(k,p,key)=>{if(key==="__by")return p.createdByName;const f=fieldsOf(k).find(x=>x[0]===key);if(!f)return"";return f[2]==="multi"?asArr(p[key]):cell(k,p,f)};
const fcls=v=>v>=30?"hi":v>=10?"mid":"lo";
function fbar(k,withQ){const f=FL[k],s=S[k],fl=fieldsOf(k).filter(x=>x[2]==="sel"||x[2]==="multi");
 const people=[...new Map(s.rows.filter(p=>p.createdBy).map(p=>[p.createdBy,p.createdByName||"—"]))];
 const vals=f.col?[...new Set(s.rows.flatMap(p=>asArr(p[f.col])).filter(Boolean))].sort():[];
 return `<div class="row">${withQ?`<input id="fq" placeholder="Search all columns..." value="${esc(f.q)}">`:""}
 <select data-f="u"><option value="">All people</option>${people.map(([id,n])=>`<option value="${esc(id)}" ${f.u===id?"selected":""}>${esc(n)}</option>`).join("")}</select>
 <input type="date" data-f="from" value="${f.from}" title="From date"><input type="date" data-f="to" value="${f.to}" title="To date">
 <select data-f="col"><option value="">Filter by column…</option>${fl.map(x=>`<option value="${x[0]}" ${f.col===x[0]?"selected":""}>${esc(x[1])}</option>`).join("")}</select>
 <select data-f="val" ${f.col?"":"disabled"}><option value="">All values</option>${vals.map(v=>`<option ${f.val===v?"selected":""}>${esc(v)}</option>`).join("")}</select>
 <button class="gry" data-a="clr">Clear filters</button></div>`}
const kpi=(l,v,c="")=>`<div class="c ${c}"><h3>${l}</h3><h2>${v}</h2></div>`;


const PU={mechParts:false,elecParts:false};
function partStats(all,key){const seen=new Set(optsOf("lucknow",key));all.forEach(p=>asArr(p[key]).forEach(x=>seen.add(x)));
 const ct=[...new Set([...optsOf("lucknow","chargerType"),...all.map(p=>p.chargerType).filter(Boolean)])];
 const m=new Map([...seen].map(o=>[o,{k:o,n:0,r:0,h:0,d:0,ct:{}}]));
 all.forEach(p=>{const bad=isFail(p),good=!bad&&isOk(p),hold=!bad&&!good&&/hold/i.test(p.repairStatus||"");
  new Set(asArr(p[key])).forEach(o=>{const g=m.get(o);if(!g)return;g.n++;if(good)g.r++;else if(bad)g.d++;else if(hold)g.h++;const c=p.chargerType||"—";g.ct[c]=(g.ct[c]||0)+1})});
 return {rows:[...m.values()].sort((a,b)=>b.n-a.n||String(a.k).localeCompare(String(b.k))),ct}}
function partsTbl(all,key,title,icon){const {rows,ct}=partStats(all,key),used=rows.filter(r=>r.n>0),show=PU[key]?rows:used,sum=used.reduce((a,r)=>a+r.n,0),mx=Math.max(1,...rows.map(r=>r.n)),isE=key==="elecParts";
 const sp=k=>{const i=String(k).indexOf(" — ");return i>=0?[String(k).slice(0,i),String(k).slice(i+3)]:[String(k),""]};
 return `<div class="sec"><h2>${icon} ${esc(title)} — Usage & Repair Result</h2>
  <p class="note">${used.length} of ${rows.length} parts used · ${sum} total uses in ${all.length} entries (filters applied). Repaired = Charger Repaired · Hold = Hold for Part · Dead = Dead. One entry counts once per part.</p>
  <div class="tw"><table><thead><tr><th>#</th><th>Part</th>${isE?"<th>Position / Sub Part</th>":""}<th>Used</th><th>Share</th><th></th><th>Repaired</th><th>Hold</th><th>Dead</th><th>Repair %</th>${ct.map(c=>`<th>${esc(c)}</th>`).join("")}</tr></thead><tbody>
  ${show.slice(0,pgN("p_"+key)).map((r,i)=>{const [a,b]=isE?sp(r.k):[r.k,""];return `<tr><td>${i+1}</td><td class="w"><b>${esc(a)}</b></td>${isE?`<td class="w">${esc(b)}</td>`:""}<td><b>${r.n}</b></td><td>${pct(r.n,all.length)}%</td><td style="width:120px"><div class="bar"><i style="width:${pct(r.n,mx)}%"></i></div></td><td style="color:#16a34a;font-weight:700">${r.r}</td><td style="color:#d97706;font-weight:700">${r.h}</td><td style="color:#dc2626;font-weight:700">${r.d}</td><td>${r.n?pct(r.r,r.n)+"%":"—"}</td>${ct.map(c=>`<td>${r.ct[c]||0}</td>`).join("")}</tr>`}).join("")||`<tr><td colspan="${9+(isE?1:0)+ct.length}">No parts used yet</td></tr>`}</tbody></table></div>${pgMore("p_"+key,show.length)}
  ${rows.length>used.length?`<div class="row" style="margin-top:10px"><button class="gry" data-a="pu" data-i="${key}">${PU[key]?"Hide unused parts":"Show unused parts too ("+(rows.length-used.length)+")"}</button></div>`:""}</div>`}
function partsDash(all){return partsTbl(all,"mechParts","Mechanical Parts","🔩")+partsTbl(all,"elecParts","Electrical Parts","⚡")}
const winSel=k=>`<span style="display:flex;gap:8px;align-items:center;flex-wrap:wrap"><label style="margin:0">Data loaded</label><select data-win="1" style="width:auto;margin:0;flex:0 0 auto;min-width:170px">${WINS.map(([d,l])=>`<option value="${d}" ${WIN[k]===d?"selected":""}>${l}</option>`).join("")}</select></span>`;
function dashLoc(){if(!BASE[dm]||!canMod(dm,"v")){const m=defMod();if(!m)return `<div class="sec"><h2>No location assigned</h2><p class="note">Your account is not linked to any location yet. Please ask the Admin to set your location in Users.</p></div>`;dm=m;ensureDash(m)}const k=dm,s=S[k],B=BASE[k],all=applyF(k,s.rows,false),n=all.length,fl=all.filter(isFail).length,ok=all.filter(isOk).length,pend=n-fl-ok;
 const stat=group(all,p=>p[B.stat]),byUser=group(all,p=>p.createdByName||"Unknown"),dimF=[...fieldsOf(k).filter(x=>x[2]==="sel"||x[2]==="multi").map(x=>[x[0],x[1]]),["__by","Added By"]];
 if(!dimF.some(x=>x[0]===DIM[k]))DIM[k]=dimF[0][0];
 const dg=group(all,p=>dimVal(k,p,DIM[k])),dshow=dg.slice(0,pgN("dim"));
 const pdiP=all.filter(p=>/^pass/i.test(p.pdiStatus||"")).length,pdiF=all.filter(p=>/fail/i.test(p.pdiStatus||"")).length;
 let acc=0;const seg=stat.map((x,i)=>{const a=acc/n*360;acc+=x.n;return `${PAL[i%8]} ${a}deg ${acc/n*360}deg`}).join(",");
 return `<div class="row"><div class="tabs" style="margin:0">${visLocs().map(l=>`<button class="${BASE[k].loc===l.id?"on":""}" data-a="locpick" data-i="${l.id}">${l.ic} ${esc(l.menu)} ▾</button>`).join("")}</div><span class="badge" style="font-size:12px;padding:6px 12px">${BASE[k].ic} ${esc(BASE[k].title)}</span>
  <span style="flex:1"></span><small style="color:var(--mut)">Updated ${lastLoad?new Date(lastLoad).toLocaleTimeString():"…"} · ${s.rows.length} entries loaded</small>
  ${winSel(k)}${s.more?`<button class="gry" data-a="dolder">⬇ Load more (stats incomplete)</button>`:""}<button class="gry" data-a="cnt">Σ Total in DB</button><button class="gry" data-a="ref">↻ Refresh</button>${canMod(k,"a")?`<button data-a="new">+ Add Entry</button>`:""}</div>
 <div class="sec"><h2>Filters</h2>${fbar(k,false)}<p class="note">Failure = Repair Status of Not OK / Non-Repairable / Scrap / Dead, or PDI Fail. Resolved = Repair Status OK / Repaired / No Issue Found. Filters apply to every chart below. For parts columns, one entry is counted once under each part used.</p></div>
 ${s.loaded?"":`<div class="sec">Loading data…</div>`}
 <div class="cards">${kpi("Total Entries",n)}${kpi("Resolved",ok,"g2")}${kpi("Failed",fl,"r2")}${kpi("In Process / On Hold",pend,"o2")}${kpi("Failure Rate",pct(fl,n)+"%","r2")}${kpi("Success Rate",pct(ok,n)+"%","g2")}
  ${isBat(k)?kpi("PDI Pass",pdiP,"g2")+kpi("PDI Fail",pdiF,"r2"):""}${hasParts(k)?kpi("Mechanical Issue",all.filter(p=>/mech/i.test(p.reportedIssue||"")).length)+kpi("Electrical Issue",all.filter(p=>/elec/i.test(p.reportedIssue||"")).length)+kpi("Mechanical Parts Used",all.reduce((a,p)=>a+asArr(p.mechParts).length,0))+kpi("Electrical Parts Used",all.reduce((a,p)=>a+asArr(p.elecParts).length,0)):""}${kpi("Active Contributors",byUser.length)}${isAdmin()?kpi("Total Users",users.filter(u=>u.role==="user").length)+kpi("Total Admins",users.filter(u=>u.role!=="user").length):""}</div>
 <div class="g2c"><div class="sec"><h2>Repair Status Distribution</h2><div style="display:flex;gap:20px;align-items:center;flex-wrap:wrap"><div class="donut" style="background:conic-gradient(${seg||"#e2e8f0 0deg 360deg"})"><div><b>${n}</b><small>Entries</small></div></div>
   <div>${stat.map((x,i)=>`<div class="leg"><i style="background:${PAL[i%8]}"></i>${esc(x.k)} <b>${x.n}</b> · ${pct(x.n,n)}%</div>`).join("")||"No data"}</div></div></div>
  <div class="sec"><h2>Efficiency by User (Success Rate)</h2>${byUser.slice(0,pgN("eff")).map(x=>`<div class="brow"><span>${esc(x.k)}</span><div class="bar"><i style="width:${pct(x.o,x.n)}%;background:#16a34a"></i></div><b>${pct(x.o,x.n)}%</b></div>`).join("")||"No data"}${pgMore("eff",byUser.length)}</div></div>
 ${hasParts(k)?partsDash(all):""}
 <div class="sec"><h2>Analyze by Column</h2><div class="row"><label style="margin:0">Group by</label><select data-dim="1">${dimF.map(x=>`<option value="${x[0]}" ${DIM[k]===x[0]?"selected":""}>${esc(x[1])}</option>`).join("")}</select></div>
  <div class="tw"><table><thead><tr><th>Value</th><th>Entries</th><th>Share</th><th></th><th>Resolved</th><th>Failed</th><th>Failure %</th></tr></thead><tbody>
  ${dshow.map(x=>`<tr><td>${esc(x.k)}</td><td>${x.n}</td><td>${pct(x.n,n)}%</td><td style="width:140px"><div class="bar"><i style="width:${pct(x.n,n)}%"></i></div></td><td>${x.o}</td><td>${x.f}</td><td><span class="pf ${fcls(x.f/x.n*100)}">${pct(x.f,x.n)}%</span></td></tr>`).join("")||"<tr><td colspan=7>No data</td></tr>"}</tbody></table></div>
  ${pgMore("dim",dg.length)}</div>
 <div class="sec"><h2>User-wise Activity & Ratio</h2><div class="tw"><table><thead><tr><th>User</th><th>Entries</th><th>Share of Total</th><th></th><th>Resolved</th><th>Failed</th><th>Failure %</th><th>Success %</th><th>Last Entry</th></tr></thead><tbody>
  ${byUser.slice(0,pgN("byu")).map(x=>`<tr><td><b>${esc(x.k)}</b></td><td>${x.n}</td><td>${pct(x.n,n)}%</td><td style="width:120px"><div class="bar"><i style="width:${pct(x.n,n)}%"></i></div></td><td>${x.o}</td><td>${x.f}</td><td><span class="pf ${fcls(x.f/x.n*100)}">${pct(x.f,x.n)}%</span></td><td>${pct(x.o,x.n)}%</td><td>${esc(x.last)}</td></tr>`).join("")||"<tr><td colspan=9>No data</td></tr>"}</tbody></table></div>${pgMore("byu",byUser.length)}</div>
 ${canLog()?`<div class="sec"><h2>Recent Activity</h2>${actTable(logs,"lmore")}</div>`:""}`}

const rowsOf=k=>S[k].search?S[k].search.rows:S[k].rows;
const findRow=(k,id)=>rowsOf(k).find(x=>x.id===id)||S[k].rows.find(x=>x.id===id);
const serialKey=k=>BASE[k].fields.find(f=>f[0]==="batterySrNo"||f[0]==="assetSrNo"||f[0]==="serialNo")?.[0]||"";
function modView(k){const s=S[k],F=fieldsOf(k),srch=!!s.search,l=applyF(k,rowsOf(k),true),n=SHOW[k],sf=serialKey(k),list=srch?l:l.slice(0,n);
 return `<div class="sec"><div class="row">${canMod(k,"a")?`<button data-a="new">+ New Entry</button>`:""}<span style="flex:1"></span>${winSel(k)}<button class="gry" data-a="cnt">Σ Total in DB</button><button class="gry" data-a="ref">↻ Refresh</button>${canMod(k,"x")?`<button class="grn" data-a="ex">Export CSV (filtered)</button>`:""}</div>
 ${sf?`<div class="row"><input id="sq" placeholder="Search serial no. in ALL data (starts with…)" value="${esc(srch?s.search.q:"")}"><button data-a="sq">🔎 Search</button>${srch?`<button class="gry" data-a="sqc">✕ Clear search</button>`:""}</div>`:""}
 ${srch?`<div class="alert">🔎 Showing up to 20 entries whose serial number starts with <b>${esc(s.search.q)}</b> (searched in the whole database).</div>`:""}
 ${fbar(k,true)}<p class="note">Showing ${list.length} of ${l.length} ${srch?"search results":"matching entries"} (${s.rows.length} loaded${s.more?", more on server":""}). Entries load 5 → 10 → 20… at a time to keep database usage low. Search box and filters below work on loaded entries; use the serial search above for the whole database.</p>
 <div class="tw"><table><thead><tr><th>Sr. No.</th>${F.map(x=>`<th>${esc(x[1])}</th>`).join("")}<th>Added By</th><th>Added On</th><th>Last Updated By</th><th class="act">Actions</th></tr></thead><tbody>
 ${list.map((p,i)=>`<tr><td>${i+1}</td>${F.map(x=>`<td class="${["reportedIssue","actionTaken","remarks","mechParts","elecParts"].includes(x[0])?"w":""}">${esc(cell(k,p,x))}</td>`).join("")}<td><b>${esc(p.createdByName||"—")}</b></td><td>${tm(p.createdAt)}</td><td>${esc(p.updatedByName||"—")}</td>
 <td class="act">${canMod(k,"e")?`<button class="gry" data-a="ed" data-i="${p.id}" title="Edit">✏️</button>`:""}${canMod(k,"d")?`<button class="red" data-a="del" data-i="${p.id}" title="Delete">🗑</button>`:""}</td></tr>`).join("")||`<tr><td colspan="${F.length+5}">No data</td></tr>`}</tbody></table></div>
 <div class="row" style="margin-top:12px">${!srch&&(l.length>n||s.more)?`<button class="gry" data-a="lm">Load More (+${PGI(n)})</button>`:""}</div></div>`}

const accSummary=u=>{if(u.role!=="user")return "Full access";const a=accOf(u);return a.custom?`Custom · ${a.locs.length} location(s)`:"Default"};
function usrView(){const n=pgN("users"),list=users.slice(0,n);return `<div class="sec"><h2>Create New User</h2><div class="g"><div><label>Full Name</label><input id="un"></div><div><label>Email</label><input id="ue" type="email"></div><div><label>Password (min 6)</label><input id="up" type="password"></div>
 <div><label>Role</label><select id="ur"><option value="user">User</option>${isOwner()?`<option value="admin">Admin</option>`:""}</select></div><div><label>Location</label><select id="ul">${LOCS.map(l=>`<option value="${l.id}">${esc(l.menu)}</option>`).join("")}</select></div></div><button data-a="cu">Create User</button>
 <p class="note">A new user starts with default access (own location). Use <b>🔐 Access</b> in the list below to give any user access to any location, section, inventory, delete / export rights, setup editing, and more.</p></div>
 <div class="sec"><h2>Users (${users.length})</h2><div class="tw"><table><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Home Location</th><th>Access</th><th>Status</th><th>Actions</th></tr></thead><tbody>${list.map(u=>{
  const mine=u.id===me.uid,cn=!mine&&u.role!=="owner"&&(isOwner()||u.role==="user");
  return `<tr><td>${esc(u.name)}</td><td>${esc(u.email)}</td><td>${cn&&isOwner()?`<select data-c="ro" data-i="${u.id}" style="margin:0"><option ${u.role==="user"?"selected":""}>user</option><option ${u.role==="admin"?"selected":""}>admin</option></select>`:esc(u.role)}</td>
  <td>${cn?`<select data-c="loc" data-i="${u.id}" style="margin:0"><option value="">— None —</option>${LOCS.map(l=>`<option value="${l.id}" ${u.location===l.id?"selected":""}>${esc(l.menu)}</option>`).join("")}</select>`:esc(locMenu(u.location)||(u.role==="user"?"—":"All"))}</td>
  <td>${esc(accSummary(u))}</td>
  <td>${cn?`<button class="${u.disabled?"grn":"red"}" data-a="dx" data-i="${u.id}">${u.disabled?"Enable":"Disable"}</button>`:(u.disabled?"Disabled":"Active")}</td>
  <td>${cn?`${u.role==="user"?`<button data-a="uacc" data-i="${u.id}">🔐 Access</button> `:""}<button class="gry" data-a="en" data-i="${u.id}">✏️ Rename</button> <button class="gry" data-a="rpw" data-i="${u.id}">🔑 Reset Password</button>`:"—"}</td></tr>`}).join("")}</tbody></table></div>${pgMore("users",users.length)}</div>`}

/* Admin assigns exactly what a user can see / do */
function accModal(uid){const u=users.find(x=>x.id===uid);if(!u||!isAdmin())return;const a=accOf(u),m=$("#modal"),P=[["v","View"],["a","Add"],["e","Edit"],["d","Delete"],["x","Export"]],
 has=(col,p)=>(a.cols[col]||[]).includes(p),ck2=(d,on)=>`<td style="text-align:center"><input type="checkbox" data-ac="${d}" ${on?"checked":""} style="width:auto;margin:0"></td>`;
 m.innerHTML=`<div class="box" style="width:940px"><h2 style="color:var(--acc)">🔐 Access — ${esc(u.name)}</h2>
 <p class="note">${a.custom?"This user has <b>custom access</b>.":"This user has the <b>default access</b> (own location, as set in User Permissions). Saving here switches the user to custom access."} Admin and Owner always have full access. Anything not ticked is hidden from the user. Delete also keeps a safety copy of the entry.</p>
 <div class="tw"><table><thead><tr><th>Location › Section</th>${P.map(c=>`<th>${c[1]}</th>`).join("")}<th>Edit dropdowns / columns</th></tr></thead><tbody>
 ${LOCS.flatMap(l=>l.mods.map(k=>`<tr><td><b>${l.ic} ${esc(l.menu)}</b> › ${BASE[k].ic} ${esc(BASE[k].title)}</td>${P.map(([p])=>ck2("c|"+k+"|"+p,has(BASE[k].col,p))).join("")}${ck2("s|"+k,a.setKeys.includes("L_"+k))}</tr>`)).join("")}</tbody></table></div>
 <h3 class="sh">📦 Inventory</h3><div class="tw"><table><thead><tr><th>Location</th><th>View stock</th><th>Manage stock (import · restock · edit · delete)</th></tr></thead><tbody>
 ${LOCS.map(l=>`<tr><td><b>${l.ic} ${esc(l.menu)}</b></td>${ck2("i|"+l.id+"|v",(a.inv[l.id]||[]).includes("v"))}${ck2("i|"+l.id+"|e",(a.inv[l.id]||[]).includes("e"))}</tr>`).join("")}</tbody></table></div>
 <h3 class="sh">Other</h3><label class="mi"><input type="checkbox" data-ac="f|log" ${a.flags.includes("log")?"checked":""}><span>Can view the Activity Log (own activity)</span></label>
 <div class="row" style="margin-top:14px"><button id="acsv">Save Access</button><button class="gry" id="acall">Tick all</button><button class="gry" id="acnone">Clear all</button><button class="red" id="acrs">Reset to default</button><button class="gry" id="pkc">Close</button></div></div>`;
 m.onchange=null;m.oninput=null;m.classList.remove("hide");$("#pkc").onclick=()=>m.classList.add("hide");
 const boxes=()=>[...m.querySelectorAll("[data-ac]")];
 $("#acall").onclick=()=>boxes().forEach(b=>b.checked=true);$("#acnone").onclick=()=>boxes().forEach(b=>b.checked=false);
 $("#acsv").onclick=async()=>{const cols={},inv={},flags=[],setKeys=[];
  boxes().forEach(el=>{if(!el.checked)return;const [t,x,y]=el.dataset.ac.split("|");
   if(t==="c"){const c=BASE[x].col;(cols[c]=cols[c]||[]).push(y)}else if(t==="s"){setKeys.push("L_"+x,"H_"+x);const c=BASE[x].col;if(!cols[c])cols[c]=[]}else if(t==="i"){(inv[x]=inv[x]||[]).push(y)}else if(t==="f")flags.push(x)});
  for(const c in cols)if(!cols[c].includes("v"))cols[c].unshift("v");
  for(const l in inv)if(inv[l].includes("e")&&!inv[l].includes("v"))inv[l].unshift("v");
  const locs=LOCS.filter(l=>l.mods.some(k=>cols[BASE[k].col])||inv[l.id]).map(l=>l.id),acc={locs,cols,inv,flags,setKeys};
  try{await withTO(updateDoc(doc(db,"users",uid),{acc}));u.acc=acc;m.classList.add("hide");render();toast("Access saved for "+u.name);log("Changed user access",u.name+": "+locs.length+" location(s)")}catch(e){fail(e)}};
 $("#acrs").onclick=async()=>{if(!await askConfirm("Reset "+u.name+" to default access?"))return;try{await withTO(updateDoc(doc(db,"users",uid),{acc:deleteField()}));delete u.acc;m.classList.add("hide");render();toast("Reset to default");log("Reset user access",u.name)}catch(e){fail(e)}}}

/* setup editor: Admin sees everything, delegated users only the sections Admin ticked */
function setView(){const adm=isAdmin(),mods=Object.keys(BASE).filter(k=>adm||canSet(k));
 if(!mods.length)return `<div class="sec"><h2>No setup access</h2><p class="note">Ask the Admin to give you "Edit dropdowns / columns" access in Users → 🔐 Access.</p></div>`;
 if(!BASE[stm]||!mods.includes(stm))stm=mods[0];
 const m=stm,P=cfg.perm,L=LOCS.find(l=>l.id===BASE[m].loc)||LOCS[0],ov=cfg.opts[ck(m)]||{},hid=hiddenOf(m),locsA=LOCS.filter(l=>l.mods.some(k=>mods.includes(k))),
  prot=new Set([BASE[m].fields[0][0],BASE[m].stat,"batterySrNo","assetSrNo","serialNo","repairLocation"]),
  pk=(id,l)=>`<label style="display:flex;gap:8px;align-items:center;text-transform:none;font-size:14px;color:var(--ink);margin-bottom:8px"><input type="checkbox" id="${id}" style="width:auto;margin:0" ${P[id]!==false?"checked":""}>${l}</label>`,
  at=`${esc(L.menu)} › ${esc(BASE[m].title)}`;
 return `${adm?locSec()+`<div class="sec"><h2>User Permissions (default)</h2><p class="note">Default rights for users who have <b>no custom access</b>. For per-user control (any location, section, inventory, delete, export…) use <b>Users → 🔐 Access</b>. Admins and the Owner always have full access. Deleting records is Admin-only unless you grant it in Access.</p>
  ${pk("userAdd","Users can add new entries")}${pk("userEdit","Users can edit entries")}${pk("userExport","Users can export CSV")}${pk("userLog","Users can view the Activity Log")}<button data-a="sp">Save Permissions</button></div>`:""}
 <div class="sec"><h2>✏️ Edit Location Setup</h2><p class="note">Step 1: choose the location · Step 2: open its Battery or Charger section · Step 3: add, rename or delete dropdown options, custom columns, or hide columns. Every location keeps its own setup — a change here affects <b>only</b> the selected location. Options that existed before stay exactly as they were until you change them.</p>
  <label>1 · Location</label><div class="tabs" style="margin-top:6px">${locsA.map(l=>`<button class="${l.id===L.id?"on":""}" data-a="sl" data-i="${l.id}">${l.ic} ${esc(l.menu)}</button>`).join("")}</div>
  <label>2 · Section</label><div class="tabs" style="margin-top:6px">${L.mods.filter(k=>mods.includes(k)).map(k=>`<button class="${k===m?"on":""}" data-a="sm" data-i="${k}">${BASE[k].ic} ${esc(BASE[k].title)}</button>`).join("")}</div>
  <div class="who" style="margin:0;display:flex;justify-content:space-between;gap:10px;align-items:center;flex-wrap:wrap"><span>Now editing: <b>${L.ic} ${at}</b></span><button class="gry" data-a="rs">↺ Reset this section to shared defaults</button></div></div>
 <div class="sec"><h2>🔽 Dropdown Manager — ${at}</h2><p class="note">Add, rename or delete options of any dropdown for this section only. Existing entries keep their saved value. For Electrical Parts use the format <b>Part — Sub Part</b> (e.g. MOSFET 60R080P7 — Q1, Q2).</p>
  ${fieldsOf(m).filter(x=>(x[2]==="sel"||x[2]==="multi")&&x[0]!=="repairLocation").map(x=>`<div style="margin-bottom:16px"><label>${esc(x[1])} ${ov[x[0]]?`<span class="badge" style="text-transform:none;background:#dcfce7;color:#166534">edited for this location</span>`:`<span class="badge" style="text-transform:none">default</span>`}</label><div style="margin-top:6px">${optsOf(m,x[0]).map((o,i)=>`<span class="chip">${esc(o)}<button data-a="oe" data-f="${x[0]}" data-i="${i}" title="Rename">✎</button><button class="x" data-a="od" data-f="${x[0]}" data-i="${i}" title="Delete">×</button></span>`).join("")||"<small style='color:var(--mut)'>No options</small>"}</div>
  <div class="row" style="margin:6px 0 0"><input id="no_${x[0]}" placeholder="New option…"><button data-a="oa" data-i="${x[0]}">Add</button></div></div>`).join("")}</div>
 <div class="sec"><h2>➕ Custom Columns — ${at}</h2><p class="note">Add extra columns to the entry form and table of this section. Deleting a column hides it; stored data is not erased. New dropdown columns get their options in the Dropdown Manager above.</p>
  <div>${customOf(m).map((c,i)=>`<span class="chip">${esc(c.label)} (${esc(c.type)})<button data-a="cr" data-i="${i}" title="Rename">✎</button><button class="x" data-a="cd" data-i="${i}">×</button></span>`).join("")||"<small style='color:var(--mut)'>No custom columns</small>"}</div>
  <div class="row" style="margin-top:10px"><input id="cn" placeholder="Column name"><select id="ct"><option value="text">Text</option><option value="date">Date</option><option value="dropdown">Dropdown</option></select><button data-a="ca">Add Column</button></div></div>
 <div class="sec"><h2>👁 Show / Hide Columns — ${at}</h2><p class="note">Hide a built-in column to remove it from this section's entry form, table, filters and analysis. Saved data is not deleted and you can show the column again any time. 🔒 = required column, cannot be hidden.</p>
  <div>${allBase(m).map(f=>`<span class="chip" style="${hid.includes(f[0])?"opacity:.55":""}">${esc(f[1])}${prot.has(f[0])?" 🔒":`<button data-a="hf" data-i="${f[0]}">${hid.includes(f[0])?"Show":"Hide"}</button>`}</span>`).join("")}</div></div>
 ${adm?brandSec()+(isOwner()?bkSec()+arcSec():""):""}`}

function brandSec(){const i=(id,l,v)=>`<div><label>${esc(l)}</label><input id="${id}" value="${esc(v)}"></div>`;
 return `<div class="sec"><h2>CRM Names & Labels</h2><p class="note">Change any text shown in the CRM (name, menus, module names, login text, column names). Leave a box empty to use the default. Applies to all users after saving.</p>
 <div class="g">${i("br_app","CRM / Login name",BR.app)}${i("br_sub","Login subtitle",BR.sub)}${i("br_wheel","Login wheel centre text",BR.wheel)}${i("br_dash","Dashboard page title",BR.dashTitle)}</div>
 <label>Menu names</label><div class="g" style="margin-top:6px">${Object.keys(DEF_BR.nav).filter(k=>!["battery","charger","lucknow"].includes(k)).map(k=>i("br_nav_"+k,DEF_BR.nav[k],BR.nav[k])).join("")}</div>
 <label>Module names</label><div class="g" style="margin-top:6px">${Object.keys(DEF_BR.mod).map(k=>i("br_mod_"+k,DEF_BR.mod[k],BR.mod[k])).join("")}</div>
 <label>Login animation steps</label><div class="g" style="margin-top:6px">${DEF_BR.steps.map((s,k)=>i("br_st_t"+k,"Step "+(k+1)+" title",BR.steps[k].t)+i("br_st_d"+k,"Step "+(k+1)+" detail",BR.steps[k].d)).join("")}</div>
 <label>Column names — ${esc(ft(stm))} (choose location &amp; section in “Edit Location Setup” above)</label><div class="g" style="margin-top:6px">${BASE[stm].fields.map(f=>i("bf_"+f[0],f[1],lbl(stm,f))).join("")}</div>
 <div class="row"><button data-a="sb">Save Names & Labels</button><button class="gry" data-a="sr">Reset all to default</button></div></div>`}
function bkSec(){return `<div class="sec"><h2>Owner Backup — Export all data</h2><p class="note">Visible only to the Owner. Each module is stored in its own Firestore collection (${Object.keys(BASE).map(k=>BASE[k].col).join(", ")}) so data never mixes. Backup reads every entry once (1 read per entry; free limit is 50,000 reads/day). For very large data, download one module CSV at a time.</p>
 <p class="note">🛡 <b>Last full backup:</b> ${cfg.meta?.lastBackup?new Date(cfg.meta.lastBackup).toLocaleString()+(cfg.meta.lastBackupBy?" by "+esc(cfg.meta.lastBackupBy):""):"never recorded"}. Deleted entries are also kept in the <b>deleted_entries</b> collection (Firebase Console) so nothing is lost by mistake.</p><div class="row"><button data-a="bkj">⬇ Full Backup (JSON: all modules + settings + users)</button>${Object.keys(BASE).map(k=>`<button class="grn" data-a="bkc" data-i="${k}">⬇ ${esc(ft(k))} CSV (all)</button>`).join("")}</div><p class="note" id="bkst"></p></div>`}
const ser=v=>{if(v&&typeof v.toDate==="function")return v.toDate().toISOString();if(Array.isArray(v))return v.map(ser);if(v&&typeof v==="object"){const o={};for(const k in v)o[k]=ser(v[k]);return o}return v};
async function pageAll(col,cb,label){let cur=null,n=0;const st=$("#bkst");for(;;){const qs=await getDocs(query(collection(db,col),...(cur?[startAfter(cur)]:[]),limit(1000)));if(!qs.docs.length)break;
  cb(qs.docs.map(d=>({id:d.id,...d.data()})));n+=qs.docs.length;cur=qs.docs[qs.docs.length-1];if(st)st.textContent=(label||col)+": "+n.toLocaleString()+" entries read…";if(qs.docs.length<1000)break}return n}
const dl=(parts,name,type)=>{const a=document.createElement("a");a.href=URL.createObjectURL(new Blob(parts,{type}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),60000)};
function locSec(){return `<div class="sec"><h2>📍 Locations / Service Centers</h2><p class="note">Every location gets its own Battery Repair and Charger Repair (separate data, dashboard and menu). Add a new location, then rename it any time with ✎. Default locations cannot be removed. Removing a custom location only hides it - its saved data is kept in the database.</p>
 <div>${LOCS.map((l,i)=>`<span class="chip">${l.ic} ${esc(l.menu)} <small style="color:var(--mut)">(${l.tpl==="lko"?"Lucknow-style forms":"Bangalore-style forms"})</small><button data-a="lr" data-i="${i}" title="Rename">✎</button>${l.sys?"":`<button class="x" data-a="ld" data-i="${i}" title="Remove">×</button>`}</span>`).join("")}</div>
 <div class="row" style="margin-top:10px"><input id="ln" placeholder="New location name (e.g. Pune Service Center)"><select id="lt"><option value="lko">Same as Lucknow / Ghaziabad (parts form)</option><option value="blr">Same as Bangalore (BSS charger form)</option></select><button data-a="la">Add Location</button></div></div>`}
function accView(){const pw=`<div class="sec"><h2>Change Password</h2><label>New Password (min 6)</label><input id="np" type="password"><label>Confirm Password</label><input id="np2" type="password"><button data-a="chpw">Change Password</button></div>`;
 return `<div class="sec"><h2>My Account</h2><label>Full Name</label><input id="myname" value="${esc(me.name)}"><label>Email</label><input value="${esc(me.email)}" disabled><label>Role</label><input value="${esc(me.role)}" disabled><label>Location</label><input value="${esc(isAdmin()?"All locations"+(locMenu(me.location)?" (home: "+locMenu(me.location)+")":""):(locMenu(me.location)||"Not assigned"))}" disabled><button data-a="savemyname">Save Name</button></div>${pw}`}
let animNext=false;
const skel=()=>`<div class="skel"><div class="cards">${[1,2,3,4].map(()=>'<div class="c"><i class="sk w40"></i><i class="sk h28"></i></div>').join("")}</div><div class="sec"><i class="sk w30"></i><i class="sk"></i><i class="sk"></i><i class="sk w70"></i></div></div>`;
let vinT=0,wasSkel=false;
function animateView(){animNext=true;const el=host.view;if(el){el.classList.remove("vin");void el.offsetWidth;el.classList.add("vin");clearTimeout(vinT);vinT=setTimeout(()=>el.classList.remove("vin"),1200)}}
function afterRender(el){if(!animNext)return;animNext=false;if(window.matchMedia&&matchMedia("(prefers-reduced-motion: reduce)").matches)return;
 el.querySelectorAll(".c h2").forEach(h=>{const t=h.textContent.trim();if(!/^\d{1,9}$/.test(t))return;const n=+t;if(n<2)return;const t0=performance.now(),D=650,f=now=>{const p=Math.min(1,(now-t0)/D);h.textContent=String(Math.round(n*(1-Math.pow(1-p,3))));if(p<1)requestAnimationFrame(f);else h.textContent=t};h.textContent="0";requestAnimationFrame(f)})}
function render(){if(!me)return;publish();const el=host.view;if(!el)return;
 const mk=view==="dash"&&dtab!=="all"?dm:(BASE[view]?view:null);
 if(mk&&BASE[mk]&&canMod(mk,"v")&&!S[mk].loaded&&!S[mk].err){el.innerHTML=skel();wasSkel=true;return}
 if(wasSkel){wasSkel=false;animateView()}
 el.innerHTML=({dash,__m:()=>modView(view),log:()=>`<div class="sec"><h2>Activity Log ${isAdmin()?"(all users)":"(my activity)"}</h2><p class="note">Shows 5 at a time (then +10, +20…). Activities older than ${LOGDAYS} days are deleted automatically.</p>${actTable(logs,"lmore")}</div>`,usr:usrView,set:setView,acc:accView,inv:invView})[BASE[view]?"__m":view]();afterRender(el)}

function formModal(k,p,title,onSave){const F=fieldsOf(k),m=$("#modal"),v={...(p||{})};
 if(!p){v[BASE[k].fields[0][0]]=today();v.repairLocation=locName(BASE[k].loc)}
 m.innerHTML=`<div class="box"><h2 style="margin-bottom:10px;color:var(--acc)">${esc(title)}</h2>
 <div class="who">👤 ${p?`Added by <b>${esc(p.createdByName||"—")}</b> on ${tm(p.createdAt)}. Your name (<b>${esc(me.name)}</b>) will be recorded as "Last Updated By".`:`This entry will be saved under <b>${esc(me.name)}</b> (${esc(me.role)}).`}<br><small>All fields are optional. The date defaults to today and can be changed.</small></div>
 <div class="g">${F.map(([key,l,t])=>{
  if(t==="sel"){const o=optsOf(k,key),ops=[...o];if(v[key]&&!ops.includes(v[key]))ops.push(v[key]);
   return `<div><label>${esc(l)}</label><select id="f_${key}" data-sel="${key}"><option value="">— Select —</option>${ops.map(x=>`<option ${v[key]===x?"selected":""}>${esc(x)}</option>`).join("")}</select>${o.some(isOther)?`<input id="f_${key}Other" placeholder="Specify details…" value="${esc(v[key+"Other"]||"")}" class="${isOther(v[key])?"":"hide"}">`:""}</div>`}
  if(t==="multi"){const o=optsOf(k,key),sel=asArr(v[key]),ops=[...o];sel.forEach(x=>{if(!ops.includes(x))ops.push(x)});
   return `<div style="grid-column:1/-1"><label>${esc(l)} <span class="msn" id="n_${key}">${sel.length} selected</span></label><input class="msq" data-q="${key}" placeholder="Search…" style="margin-bottom:6px"><div class="ms" id="f_${key}">${ops.map(x=>`<label class="mi"><input type="checkbox" data-v="${esc(x)}" ${sel.includes(x)?"checked":""}><span style="flex:1">${esc(x)}</span><input type="number" class="pq ${sel.includes(x)?"":"hide"}" min="1" step="1" value="${(v.partQty&&v.partQty[x])||1}" title="Quantity used (deducted from inventory)" style="width:70px;height:32px;margin:0;padding:4px 6px"></label>`).join("")||"<small style='color:var(--mut)'>No options yet. Add them in Admin Settings.</small>"}</div></div>`}
  if(t==="area")return `<div style="grid-column:1/-1"><label>${esc(l)}</label><textarea id="f_${key}">${esc(v[key]||"")}</textarea></div>`;
  return `<div><label>${esc(l)}</label><input id="f_${key}" type="${t}" value="${esc(v[key]||"")}"></div>`}).join("")}</div>
 <div class="row" style="margin-top:14px"><button id="ps">Save Entry</button><button class="gry" id="pc">Cancel</button></div></div>`;
 m.classList.remove("hide");
 m.onchange=e=>{const key=e.target.dataset?.sel,o=key&&$("#f_"+key+"Other");if(o)o.classList.toggle("hide",!isOther(e.target.value));
  const ms=e.target.closest&&e.target.closest(".ms");if(ms){const pq=e.target.type==="checkbox"&&e.target.closest(".mi")?.querySelector(".pq");if(pq)pq.classList.toggle("hide",!e.target.checked);const nn=$("#n_"+ms.id.slice(2));if(nn)nn.textContent=ms.querySelectorAll("input:checked").length+" selected"}};
 m.oninput=e=>{const q=e.target.dataset?.q;if(!q)return;const s=e.target.value.toLowerCase();document.querySelectorAll("#f_"+q+" .mi").forEach(x=>x.classList.toggle("hide",!x.textContent.toLowerCase().includes(s)))};
 $("#pc").onclick=()=>m.classList.add("hide");
 $("#ps").onclick=async()=>{const d={},pqm={};
  F.forEach(([key,,t])=>{const el=$("#f_"+key);
   if(t==="multi"){const ch=el?[...el.querySelectorAll("input[type=checkbox]:checked")]:[];d[key]=ch.map(c=>c.dataset.v);ch.forEach(c=>{const q=Math.max(1,Math.floor(+(c.closest(".mi").querySelector(".pq")?.value)||1));if(q>1)pqm[c.dataset.v]=q});return}
   d[key]=el?el.value.trim():"";
   if(t==="sel"){const ot=$("#f_"+key+"Other"),nv=ot&&isOther(d[key])?ot.value.trim():"";if(nv||(p&&p[key+"Other"]))d[key+"Other"]=nv}});
  if(F.some(f=>f[2]==="multi"))d.partQty=pqm;
  $("#ps").disabled=true;
  try{await onSave(d);m.classList.add("hide");toast("Entry saved successfully")}catch(e){fail(e);$("#ps").disabled=false}}}

const sid=(k,d)=>d.batterySrNo||d.assetSrNo||d.serialNo||d.iotImei||"(no serial)";
async function saveOpts(m,f,arr,msg){try{await setDoc(doc(db,"config","options"),{[ck(m)]:{[f]:arr}},{merge:true});cfg.opts[ck(m)]={...(cfg.opts[ck(m)]||{}),[f]:arr};render();log("Updated dropdown",ft(m)+" › "+f+" ("+msg+")")}catch(e){fail(e)}}
async function saveFields(m,arr,msg){try{await setDoc(doc(db,"config","fields"),{[ck(m)]:arr},{merge:true});cfg.custom[ck(m)]=arr;render();log("Updated custom columns",ft(m)+" ("+msg+")")}catch(e){fail(e)}}
async function saveLocs(next,msg){if(!isAdmin())return;try{await withTO(setDoc(doc(db,"config","locations"),{list:next.map(l=>({id:l.id,name:l.name,menu:l.menu,ic:l.ic,tpl:l.tpl}))}));
  applyLocs(next);buildLocNav();if(!BASE[dm]||!canLoc(BASE[dm].loc))dm=defMod()||"battery";
  if(BASE[view]===undefined&&!["dash","log","usr","set","acc"].includes(view))view="set";
  render();log("Updated locations",msg);toast("Locations saved")}catch(e){fail(e)}}
let lastRef=0;
const H={
 ref:async()=>{if(Date.now()-lastRef<60000)return toast("Already up to date (refreshed less than a minute ago).");lastRef=Date.now();await refreshAll();toast("Data refreshed")},
 clr:()=>{FL[curMod()]=EF();SHOW[curMod()]=5;render()},
 locpick:i=>pickModal(i,"dash"),
 la:()=>{const name=$("#ln").value.trim(),tpl=$("#lt").value;if(!name)return toast("Enter a location name.");
  const base=name.toLowerCase().replace(/[^a-z0-9]+/g,"").slice(0,12)||"loc";let id=base,n=1;while(id.length<2||LOCS.some(l=>l.id===id))id=base+(++n);
  saveLocs([...LOCS,{id,name,menu:name,ic:"📍",tpl}],"added "+name)},
 lr:async i=>{const l=LOCS[i],n=await askPrompt("Rename location:",l.menu);if(!n||!n.trim()||n.trim()===l.menu)return;const a=LOCS.map(x=>({...x}));a[i].name=n.trim();a[i].menu=n.trim();saveLocs(a,"renamed "+l.menu+" → "+n.trim())},
 ld:async i=>{const l=LOCS[i];if(!l||l.sys||!await askConfirm('Remove location "'+l.menu+'"? Its data stays in the database but it will be hidden. Users assigned to it lose access.'))return;saveLocs(LOCS.filter((_,j)=>j!==+i),"removed "+l.menu)},dall:()=>{DALL[dm]=!DALL[dm];render()},
 lm:()=>{const k=view,l=applyF(k,S[k].rows,true);SHOW[k]+=40;if(l.length<SHOW[k]&&S[k].more)loadMod(k,true,40);else render()},dmore:()=>{dLog+=10;render()},lmore:()=>{lLog+=10;render()},
 new:()=>{const k=curMod();if(!canMod(k,"a"))return;const id=nid();formModal(k,null,"New "+ft(k)+" Entry",async d=>{
  const extra={createdBy:me.uid,createdByName:me.name,createdByRole:me.role};
  const meta={module:k,loc:BASE[k].loc,entryDate:ymd(d)};
  await saveEntry(k,id,{...d,...extra,...meta,createdAt:serverTimestamp()},null,d);
  S[k].search=null;S[k].rows.unshift({id,...d,...extra,...meta,createdAt:new Date()});render();log("Added "+ft(k)+" entry",sid(k,d))})},
 ed:i=>{const k=view,p=findRow(k,i);if(!p||!canMod(k,"e"))return;
  formModal(k,p,"Edit "+ft(k)+" Entry",async d=>{const extra={updatedBy:me.uid,updatedByName:me.name};
   const meta={module:k,loc:BASE[k].loc,entryDate:ymd(d)};await saveEntry(k,i,{...d,...extra,...meta,updatedAt:serverTimestamp()},p,d);Object.assign(p,d,extra,meta,{updatedAt:new Date()});{const q=S[k].rows.find(x=>x.id===i);if(q&&q!==p)Object.assign(q,d,extra,meta,{updatedAt:new Date()})}render();log("Edited "+ft(k)+" entry",sid(k,d))})},
 del:async i=>{const k=view,p=findRow(k,i);if(!canMod(k,"d"))return;if(!await askConfirm("Permanently delete this entry? A safety copy is stored in the deleted-entries archive."))return;
  try{const b=writeBatch(db);if(p){const cp={};for(const [a,v] of Object.entries(p)){if(a==="id")continue;cp[a]=v&&typeof v.toDate==="function"?v.toDate().toISOString():(v instanceof Date?v.toISOString():v)}
    b.set(doc(db,"deleted_entries",nid()),{...cp,_collection:BASE[k].col,_docId:i,_deletedBy:me.uid,_deletedByName:me.name,_deletedAt:serverTimestamp()})}
   b.delete(doc(db,BASE[k].col,i));await withTO(b.commit());S[k].rows=S[k].rows.filter(x=>x.id!==i);if(S[k].search)S[k].search.rows=S[k].search.rows.filter(x=>x.id!==i);render();toast("Entry deleted (safety copy archived)");log("Deleted "+ft(k)+" entry",p?sid(k,p):i)}catch(e){fail(e)}},
 ex:()=>{const k=view;if(!canMod(k,"x"))return;const F=fieldsOf(k),qt=v=>`"${String(v??"").replace(/"/g,'""')}"`,l=applyF(k,rowsOf(k),true);
  const out=[['"Sr. No."',...F.map(f=>qt(f[1])),'"Added By"','"Added On"','"Last Updated By"'].join(",")];
  l.forEach((p,i)=>out.push([i+1,...F.map(f=>qt(cell(k,p,f))),qt(p.createdByName),qt(tm(p.createdAt)),qt(p.updatedByName)].join(",")));
  const a=document.createElement("a");a.href=URL.createObjectURL(new Blob(["\ufeff"+out.join("\n")],{type:"text/csv"}));a.download=BASE[k].col+"_"+today()+".csv";a.click();toast("Exported "+l.length+" rows");log("Exported CSV",ft(k)+" ("+l.length+" rows)")},
 chpw:async()=>{const a=$("#np").value,b=$("#np2").value;if(a.length<6)return toast("Password must be at least 6 characters.");if(a!==b)return toast("Passwords do not match.");
  try{await updatePassword(auth.currentUser,a);$("#np").value="";$("#np2").value="";toast("Password updated");log("Changed password")}catch(e){toast(errMsg(e))}},
 savemyname:async()=>{const n=$("#myname").value.trim();if(!n)return;try{await updateDoc(doc(db,"users",me.uid),{name:n});me.name=n;publish();toast("Name updated")}catch(e){fail(e)}},
 cu:async()=>{const name=$("#un").value.trim(),email=$("#ue").value.trim(),pw=$("#up").value,role=$("#ur").value,location=$("#ul").value;
  if(!name||!email||pw.length<6)return toast("Enter a name, email and a password of at least 6 characters.");if(role!=="user"&&!isOwner())return toast("Only the Owner can create admins.");
  const s=initializeApp(firebaseConfig,"sec"+Date.now());if(APPCHECK){try{APPCHECK.initializeAppCheck(s,{provider:new APPCHECK.ReCaptchaV3Provider(APPCHECK_SITE_KEY),isTokenAutoRefreshEnabled:true})}catch(_){}}const a=getAuth(s);
  try{const c=await createUserWithEmailAndPassword(a,email,pw);const prof={name,email,role,location,disabled:false,createdBy:me.uid,createdAt:serverTimestamp()};
   await setDoc(doc(db,"users",c.user.uid),prof);users.push({id:c.user.uid,...prof,createdAt:new Date()});render();toast("User created");log("Created user",name+" ("+role+")")}
  catch(e){if(e.code&&e.code.startsWith("auth/"))toast(errMsg(e));else fail(e)}
  await signOut(a).catch(()=>{});await deleteApp(s).catch(()=>{})},
 dx:async i=>{const u=users.find(x=>x.id===i);try{await updateDoc(doc(db,"users",i),{disabled:!u.disabled});u.disabled=!u.disabled;render();log(u.disabled?"Disabled user":"Enabled user",u.name)}catch(e){fail(e)}},
 en:async i=>{const u=users.find(x=>x.id===i),n=await askPrompt("New name:",u.name);if(!n||!n.trim())return;try{await updateDoc(doc(db,"users",i),{name:n.trim()});u.name=n.trim();render()}catch(e){fail(e)}},
 rpw:async i=>{const u=users.find(x=>x.id===i);try{await sendPasswordResetEmail(auth,u.email);toast("Password reset email sent");log("Sent password reset",u.name)}catch(e){toast(errMsg(e))}},
 sm:i=>{stm=i;render()},
  pu:i=>{PU[i]=!PU[i];render()},
  dolder:()=>loadMod(dm,true,FETCH),
  cnt:async()=>{const k=curMod();try{const r=await getCountFromServer(collection(db,BASE[k].col));toast(ft(k)+": "+r.data().count.toLocaleString()+" entries in database")}catch(e){fail(e)}},
  cr:async i=>{const a=[...customOf(stm)],n=await askPrompt("Rename column:",a[i].label);if(!n||!n.trim())return;const old=a[i].label;a[i]={...a[i],label:n.trim()};saveFields(stm,a,"renamed "+old+" → "+n.trim())},
  sb:async()=>{const g=id=>($("#"+id)?.value||"").trim(),o={app:g("br_app"),sub:g("br_sub"),wheel:g("br_wheel"),dashTitle:g("br_dash"),nav:{},mod:{},steps:[],fl:{...(BR.fl||{})}};
   for(const k in DEF_BR.nav)o.nav[k]=g("br_nav_"+k);for(const k in DEF_BR.mod)o.mod[k]=g("br_mod_"+k);DEF_BR.steps.forEach((_,i)=>o.steps.push({t:g("br_st_t"+i),d:g("br_st_d"+i)}));
   const fl={};BASE[stm].fields.forEach(f=>{const v=g("bf_"+f[0]);if(v&&v!==f[1])fl[f[0]]=v.slice(0,60)});o.fl[ck(stm)]=fl;
   try{await withTO(setDoc(doc(db,"config","branding"),o));BR=mergeBR(o);try{localStorage.setItem("brand",JSON.stringify(o))}catch(_){}applyBrand();nav("set");toast("Names & labels saved");log("Updated CRM names & labels","")}catch(e){fail(e)}},
  sr:async()=>{if(!await askConfirm("Reset ALL names and labels to default?"))return;try{await setDoc(doc(db,"config","branding"),{});BR=mergeBR({});try{localStorage.removeItem("brand")}catch(_){}applyBrand();nav("set");toast("Reset to default");log("Reset CRM names & labels","")}catch(e){fail(e)}},
  bkj:async()=>{if(!isOwner())return;if(!await askConfirm("Backup reads every entry once (1 read per entry). Continue?"))return;const st=$("#bkst"),parts=[];let first=true;
   try{parts.push('{"exportedAt":'+JSON.stringify(new Date().toISOString())+',"app":'+JSON.stringify(BR.app)+',"modules":{');
    for(const k of Object.keys(BASE)){parts.push((first?"":",")+JSON.stringify(k)+':{"collection":'+JSON.stringify(BASE[k].col)+',"title":'+JSON.stringify(ft(k))+',"columns":'+JSON.stringify(fieldsOf(k).map(f=>({key:f[0],label:f[1]})))+',"rows":[');first=false;let f2=true;
     await pageAll(BASE[k].col,rows=>{parts.push((f2?"":",")+rows.map(r=>JSON.stringify(ser(r))).join(","));f2=false},ft(k));parts.push("]}")}
    parts.push('},"config":{');const cf=[];for(const id of["options","fields","permissions","branding"]){try{const s=await getDoc(doc(db,"config",id));cf.push(JSON.stringify(id)+":"+JSON.stringify(s.exists()?ser(s.data()):{}))}catch(_){cf.push(JSON.stringify(id)+":{}")}}
    const iv={};for(const l of LOCS){for(const c of ["inventory","inventory_use"]){try{const sn=await getDoc(doc(db,c,l.id));iv[c+"/"+l.id]=sn.exists()?ser(sn.data()):null}catch(_){}}}
  parts.push(cf.join(",")+'},"users":'+JSON.stringify(ser(users.map(u=>({...u}))))+',"inventory":'+JSON.stringify(iv)+"}");
    dl(parts,"crm_backup_"+today()+".json","application/json");if(st)st.textContent="Backup downloaded.";markBackup();log("Owner full backup (JSON)","")}catch(e){if(st)st.textContent="Backup failed: "+(e.code||e.message);fail(e)}},
  bkc:async k=>{if(!isOwner())return;if(!await askConfirm("Export reads every entry once (1 read per entry). Continue?"))return;const F=fieldsOf(k),qt=v=>`"${String(v??"").replace(/"/g,'""')}"`,st=$("#bkst");let n=0;
   const parts=["\ufeff"+[['"Sr. No."','"Document ID"',...F.map(f=>qt(f[1])),'"Added By"','"Added On"','"Last Updated By"'].join(",")]+"\n"];
   try{await pageAll(BASE[k].col,rows=>{parts.push(rows.map(p=>[++n,qt(p.id),...F.map(f=>qt(cell(k,p,f))),qt(p.createdByName),qt(tm(p.createdAt)),qt(p.updatedByName)].join(",")).join("\n")+"\n")},ft(k));
    dl(parts,BASE[k].col+"_ALL_"+today()+".csv","text/csv");if(st)st.textContent=ft(k)+": "+n.toLocaleString()+" rows exported.";log("Owner backup CSV",ft(k)+" ("+n+" rows)")}catch(e){if(st)st.textContent="Export failed: "+(e.code||e.message);fail(e)}},
 sp:async()=>{const p={};["userAdd","userEdit","userExport","userLog"].forEach(id=>p[id]=$("#"+id).checked);try{await setDoc(doc(db,"config","permissions"),p);cfg.perm=p;toast("Permissions saved");log("Updated user permissions",JSON.stringify(p));publish()}catch(e){fail(e)}},
 oa:i=>{const v=$("#no_"+i).value.trim();if(!v)return;const a=[...optsOf(stm,i)];if(a.includes(v))return toast("Option already exists.");a.push(v);saveOpts(stm,i,a,"added "+v)},
 oe:async(i,b)=>{const f=b.dataset.f,a=[...optsOf(stm,f)],n=await askPrompt("Rename option:",a[i]);if(!n||!n.trim()||n.trim()===a[i])return;const old=a[i];a[i]=n.trim();saveOpts(stm,f,a,old+" → "+a[i])},
 od:async(i,b)=>{const f=b.dataset.f,a=[...optsOf(stm,f)];if(!await askConfirm('Delete option "'+a[i]+'"?'))return;const old=a.splice(i,1)[0];saveOpts(stm,f,a,"deleted "+old)},
 ca:()=>{const label=$("#cn").value.trim(),type=$("#ct").value;if(!label)return toast("Enter a column name.");const a=[...customOf(stm)];
  const key="x_"+label.toLowerCase().replace(/[^a-z0-9]+/g,"_").slice(0,24)+"_"+Math.random().toString(36).slice(2,5);a.push({key,label,type});saveFields(stm,a,"added "+label)},
 cd:async i=>{const a=[...customOf(stm)];if(!await askConfirm('Remove column "'+a[i].label+'"? Stored data is kept.'))return;const old=a.splice(i,1)[0];saveFields(stm,a,"removed "+old.label)}
};
Object.assign(H,{
 sl:i=>{const l=LOCS.find(x=>x.id===i);if(!l)return;const cur=LOCS.find(x=>x.id===BASE[stm]?.loc),idx=Math.max(0,(cur?cur.mods:[]).indexOf(stm));stm=l.mods[idx]||l.mods[0];render()},
 hf:async i=>{const a=[...hiddenOf(stm)],j=a.indexOf(i);if(j>=0)a.splice(j,1);else a.push(i);
  try{await setDoc(doc(db,"config","fields"),{["H_"+stm]:a},{merge:true});cfg.custom["H_"+stm]=a;render();log("Updated columns",ft(stm)+" ("+(j>=0?"shown ":"hidden ")+i+")")}catch(e){fail(e)}},
 rs:async()=>{if(!await askConfirm('Reset "'+ft(stm)+'" to the shared default setup? Location-specific dropdown options, custom columns, hidden columns and column names of this section will be removed (saved entries are kept).'))return;
  try{const k=ck(stm);await setDoc(doc(db,"config","options"),{[k]:deleteField()},{merge:true});await setDoc(doc(db,"config","fields"),{[k]:deleteField(),["H_"+stm]:deleteField()},{merge:true});
   if(isAdmin()&&BR.fl&&BR.fl[k]){await setDoc(doc(db,"config","branding"),{fl:{[k]:deleteField()}},{merge:true});delete BR.fl[k];try{localStorage.removeItem("brand")}catch(_){}}
   delete cfg.opts[k];delete cfg.custom[k];delete cfg.custom["H_"+stm];render();toast("Section reset to shared defaults");log("Reset section setup",ft(stm))}catch(e){fail(e)}}
});


/* ===== OVERALL ANALYTICS (all locations combined) ===== */
let dtab="loc",ovBusy=false;
const PALL={battery:false,charger:false};
const OF={loc:"",cat:"",st:"",from:"",to:"",q:"",pre:"",len:3};
const CATL={battery:"🔋 Battery",charger:"⚡ Charger"};
const serialOf=p=>String(p.batterySrNo||p.assetSrNo||p.serialNo||"").trim();
const prefOf=(sr,n)=>{const s=String(sr||"").replace(/\s+/g,"").toUpperCase();return s?s.slice(0,n):"(no serial)"};
const catOf=k=>isBat(k)?"battery":"charger";
const stOf=p=>isFail(p)?"f":isOk(p)?"o":"p";
const ecls=v=>v>=70?"lo":v>=40?"mid":"hi";
const agg=a=>{const n=a.length,f=a.filter(x=>x.st==="f").length,o=a.filter(x=>x.st==="o").length;return {n,f,o,p:n-f-o}};
function ovRows(){const out=[],q=OF.q.toLowerCase(),pre=OF.pre.replace(/\s+/g,"").toUpperCase();
 for(const l of visLocs()){if(OF.loc&&OF.loc!==l.id)continue;
  for(const k of l.mods){if(!canMod(k,"v"))continue;const cat=catOf(k);if(OF.cat&&OF.cat!==cat)continue;
   for(const p of S[k].rows){const d=ymd(p);if(OF.from&&d<OF.from)continue;if(OF.to&&d>OF.to)continue;
    const st=stOf(p);if(OF.st&&OF.st!==st)continue;const sr=serialOf(p);
    if(pre&&!sr.replace(/\s+/g,"").toUpperCase().startsWith(pre))continue;
    if(q&&!sr.toLowerCase().includes(q))continue;
    out.push({p,k,loc:l.id,cat,sr,st,pf:prefOf(sr,OF.len)})}}}
 return out}
async function ovLoad(full){if(ovBusy)return;ovBusy=true;render();
 try{for(const l of visLocs())for(const k of l.mods){if(!canMod(k,"v"))continue;if(!S[k].loaded)await loadMod(k,false,FETCH);
   if(full)while(S[k].loaded&&S[k].more){const b=S[k].rows.length;await loadMod(k,true,FETCH);if(S[k].rows.length===b)break}}}
 finally{ovBusy=false;render()}}
function modeBar(){return `<div class="seg"><button class="${dtab==="loc"?"on":""}" data-a="dtab" data-i="loc">📍 Location Dashboard</button><button class="${dtab==="all"?"on":""}" data-a="dtab" data-i="all">🌐 Overall Analytics · All Locations</button></div>`}
function ovFilters(vl){const sel=(id,l,o,v)=>`<div><label>${l}</label><select data-of="${id}">${o.map(([a,b])=>`<option value="${esc(a)}" ${String(v)===String(a)?"selected":""}>${esc(b)}</option>`).join("")}</select></div>`;
 return `<div class="fgrid">${sel("loc","Location",[["","All locations"],...vl.map(l=>[l.id,l.menu])],OF.loc)}${sel("cat","Type",[["","Battery + Charger"],["battery","Battery only"],["charger","Charger only"]],OF.cat)}${sel("st","Status",[["","All status"],["f","Faulty only"],["o","Resolved only"],["p","Pending / Hold only"]],OF.st)}${sel("len","Group serial by",[1,2,3,4,5,6,7,8].map(n=>[n,"First "+n+" character"+(n>1?"s":"")]),OF.len)}
 <div><label>From date</label><input type="date" data-of="from" value="${esc(OF.from)}"></div><div><label>To date</label><input type="date" data-of="to" value="${esc(OF.to)}"></div>
 <div><label>Serial starts with</label><input data-of="pre" placeholder="e.g. VSC" value="${esc(OF.pre)}"></div><div><label>Serial contains</label><input data-of="q" placeholder="Search serial…" value="${esc(OF.q)}"></div></div>
 <div class="row"><button class="gry" data-a="ovclr">Clear filters</button></div>`}
function pfTable(cat,rows,locs){
 const list=rows.filter(x=>x.cat===cat),g=new Map();
 list.forEach(x=>{let e=g.get(x.pf);if(!e){e={k:x.pf,n:0,f:0,o:0,loc:{}};g.set(x.pf,e)}
  e.n++;if(x.st==="f")e.f++;else if(x.st==="o")e.o++;
  const L=e.loc[x.loc]||(e.loc[x.loc]={n:0,f:0});L.n++;if(x.st==="f")L.f++});
 const arr=[...g.values()].sort((a,b)=>b.n-a.n||a.k.localeCompare(b.k)),N=list.length,mx=Math.max(1,...arr.map(e=>e.n)),show=arr.slice(0,pgN("pf_"+cat)),T=agg(list);
 const lc=(e,id)=>{const L=e.loc[id];return L?`<b>${L.n}</b>${L.f?` <small style="color:#dc2626">(${L.f} faulty)</small>`:""}`:"<span style='color:var(--mut)'>0</span>"};
 const lt=id=>{const z=agg(list.filter(x=>x.loc===id));return `<b>${z.n}</b>${z.f?` <small style="color:#dc2626">(${z.f} faulty)</small>`:""}`};
 return `<div class="sec"><h2>${CATL[cat]} — Serial Number Series (first ${OF.len} characters)</h2>
  <p class="note">${arr.length} different series · ${N} entries. Faulty = Non-Repairable / Scrap / Dead / Not OK / PDI Fail. Use <b>Details</b> for location split, top issues and the faulty serial numbers of that series.</p>
  <div class="tw"><table><thead><tr><th>#</th><th>Starts with</th><th>Total</th><th>Share</th><th></th><th>Resolved</th><th>Faulty</th><th>Pending</th><th>Fault %</th><th>Efficiency</th>${locs.map(l=>`<th>${esc(l.menu)}</th>`).join("")}<th></th></tr></thead><tbody>
  ${show.map((e,i)=>`<tr><td>${i+1}</td><td><b>${esc(e.k)}</b></td><td><b>${e.n}</b></td><td>${pct(e.n,N)}%</td><td style="width:110px"><div class="bar"><i style="width:${pct(e.n,mx)}%"></i></div></td><td style="color:#16a34a;font-weight:700">${e.o}</td><td style="color:#dc2626;font-weight:700">${e.f}</td><td style="color:#d97706;font-weight:700">${e.n-e.o-e.f}</td><td><span class="pf ${fcls(e.f/e.n*100)}">${pct(e.f,e.n)}%</span></td><td>${pct(e.o,e.n)}%</td>${locs.map(l=>`<td>${lc(e,l.id)}</td>`).join("")}<td><button class="gry" data-a="pd" data-i="${esc(cat+"|"+e.k)}">Details</button></td></tr>`).join("")||`<tr><td colspan="${11+locs.length}">No entries match the filters</td></tr>`}
  </tbody>${arr.length?`<tfoot><tr><td></td><td>TOTAL</td><td>${T.n}</td><td>100%</td><td></td><td>${T.o}</td><td>${T.f}</td><td>${T.p}</td><td>${pct(T.f,T.n)}%</td><td>${pct(T.o,T.n)}%</td>${locs.map(l=>`<td>${lt(l.id)}</td>`).join("")}<td></td></tr></tfoot>`:""}</table></div>
  ${pgMore("pf_"+cat,arr.length)}</div>`}
function issueTable(cat,rows){const list=rows.filter(x=>x.cat===cat),N=list.length,gA=group(list.map(x=>x.p),p=>p.reportedIssue||""),g=gA.slice(0,pgN("is_"+cat)),mx=Math.max(1,...gA.map(x=>x.n));
 return `<div class="sec"><h2>${CATL[cat]} — Top Reported Issues (all locations)</h2><div class="tw"><table><thead><tr><th>Issue</th><th>Entries</th><th>Share</th><th></th><th>Resolved</th><th>Faulty</th><th>Fault %</th></tr></thead><tbody>
 ${g.map(x=>`<tr><td class="w">${esc(x.k)}</td><td><b>${x.n}</b></td><td>${pct(x.n,N)}%</td><td style="width:110px"><div class="bar"><i style="width:${pct(x.n,mx)}%"></i></div></td><td>${x.o}</td><td>${x.f}</td><td><span class="pf ${fcls(x.f/x.n*100)}">${pct(x.f,x.n)}%</span></td></tr>`).join("")||"<tr><td colspan=7>No data</td></tr>"}</tbody></table></div>${pgMore("is_"+cat,gA.length)}</div>`}
function ovDash(){
 const vl=visLocs(),mods=vl.flatMap(l=>l.mods).filter(k=>canMod(k,"v")),loaded=mods.filter(k=>S[k].loaded).length,moreK=mods.filter(k=>S[k].more),
  rows=ovRows(),A=agg(rows),Bt=agg(rows.filter(x=>x.cat==="battery")),Ch=agg(rows.filter(x=>x.cat==="charger")),
  locs=vl.filter(l=>!OF.loc||OF.loc===l.id),ef=a=>pct(a.o,a.n),cs=a=>pct(a.o,a.o+a.f);
 const lr=locs.map(l=>{const r=rows.filter(x=>x.loc===l.id);return {l,b:agg(r.filter(x=>x.cat==="battery")),c:agg(r.filter(x=>x.cat==="charger")),t:agg(r)}});
 const eff=a=>a.n?`<span class="pf ${ecls(a.o/a.n*100)}">${ef(a)}%</span>`:"—";
 const cells=a=>`<td>${a.n}</td><td style="color:#16a34a;font-weight:700">${a.o}</td><td style="color:#dc2626;font-weight:700">${a.f}</td><td>${eff(a)}</td>`;
 const tot=(l,b,c,t)=>`<td>${t.n}</td><td style="color:#dc2626;font-weight:700">${t.f}</td><td>${eff(t)}</td><td style="width:110px"><div class="bar"><i style="width:${ef(t)}%;background:#16a34a"></i></div></td>`;
 return `<div class="row"><span style="flex:1;min-width:220px"><b style="font-size:16px;color:var(--acc)">Overall Analytics</b><br><small style="color:var(--mut)">Battery &amp; Charger of every location combined · ${loaded}/${mods.length} sections loaded · ${rows.length} entries after filters</small></span>
  <span style="display:flex;gap:8px;align-items:center;flex-wrap:wrap"><label style="margin:0">Data loaded</label><select data-owin="1" style="width:auto;margin:0;min-width:170px">${WINS.map(([d,l])=>`<option value="${d}" ${(WIN[mods[0]]||0)===d?"selected":""}>${l}</option>`).join("")}</select></span>
  <button class="gry" data-a="ovfull">⬇ Load complete data</button><button class="gry" data-a="ref">↻ Refresh</button><button class="grn" data-a="ovex">Export CSV</button><button class="gry" data-a="opr">🖨 Print</button></div>
 ${ovBusy?`<div class="alert">⏳ Loading data from all locations…</div>`:""}
 ${moreK.length&&!ovBusy?`<div class="alert">⚠ ${moreK.length} section(s) have more entries on the server than loaded. Press <b>Load complete data</b> for exact totals.</div>`:""}
 <div class="sec"><h2>Filters</h2>${ovFilters(vl)}<p class="note">All numbers below follow these filters. Efficiency = Resolved ÷ Total entries. Faulty = Repair Status Not OK / Non-Repairable / Scrap / Dead or PDI Fail. Resolved = OK / Repaired / No Issue Found. The rest is Pending / On Hold.</p></div>
 <h3 class="sh">Combined — Battery + Charger, all locations</h3>
 <div class="cards">${kpi("Total Entries",A.n)}${kpi("Resolved",A.o,"g2")}${kpi("Faulty",A.f,"r2")}${kpi("Pending / Hold",A.p,"o2")}${kpi("Overall Efficiency",ef(A)+"%","g2")}${kpi("Failure Rate",pct(A.f,A.n)+"%","r2")}${kpi("Success on Closed Cases",cs(A)+"%","g2")}${kpi("Locations",locs.length)}</div>
 <h3 class="sh">🔋 Battery — all locations</h3>
 <div class="cards">${kpi("Battery Entries",Bt.n)}${kpi("Resolved",Bt.o,"g2")}${kpi("Faulty",Bt.f,"r2")}${kpi("Pending / Hold",Bt.p,"o2")}${kpi("Battery Efficiency",ef(Bt)+"%","g2")}${kpi("Failure Rate",pct(Bt.f,Bt.n)+"%","r2")}</div>
 <h3 class="sh">⚡ Charger — all locations</h3>
 <div class="cards">${kpi("Charger Entries",Ch.n)}${kpi("Resolved",Ch.o,"g2")}${kpi("Faulty",Ch.f,"r2")}${kpi("Pending / Hold",Ch.p,"o2")}${kpi("Charger Efficiency",ef(Ch)+"%","g2")}${kpi("Failure Rate",pct(Ch.f,Ch.n)+"%","r2")}</div>
 <div class="sec"><h2>Overall Efficiency Summary</h2>
  <div class="brow"><span>🔋 Battery (all locations)</span><div class="bar"><i style="width:${ef(Bt)}%;background:#16a34a"></i></div><b>${ef(Bt)}%</b></div>
  <div class="brow"><span>⚡ Charger (all locations)</span><div class="bar"><i style="width:${ef(Ch)}%;background:#16a34a"></i></div><b>${ef(Ch)}%</b></div>
  <div class="brow"><span><b>Combined</b></span><div class="bar"><i style="width:${ef(A)}%;background:#1e4e79"></i></div><b>${ef(A)}%</b></div></div>
 <div class="sec"><h2>📍 Location-wise Efficiency</h2><div class="tw"><table><thead><tr><th rowspan="2">Location</th><th colspan="4" class="grp">🔋 Battery</th><th colspan="4" class="grp">⚡ Charger</th><th colspan="4" class="grp">Combined</th></tr>
  <tr><th>Entries</th><th>Resolved</th><th>Faulty</th><th>Efficiency</th><th>Entries</th><th>Resolved</th><th>Faulty</th><th>Efficiency</th><th>Entries</th><th>Faulty</th><th>Efficiency</th><th></th></tr></thead><tbody>
  ${lr.map(x=>`<tr><td><b>${x.l.ic} ${esc(x.l.menu)}</b></td>${cells(x.b)}${cells(x.c)}${tot(x.l,x.b,x.c,x.t)}</tr>`).join("")||"<tr><td colspan=13>No data</td></tr>"}</tbody>
  <tfoot><tr><td>ALL LOCATIONS</td>${cells(Bt)}${cells(Ch)}${tot(0,Bt,Ch,A)}</tr></tfoot></table></div></div>
 ${(OF.cat!=="charger"?pfTable("battery",rows,locs):"")}${(OF.cat!=="battery"?pfTable("charger",rows,locs):"")}
 ${(OF.cat!=="charger"?issueTable("battery",rows):"")}${(OF.cat!=="battery"?issueTable("charger",rows):"")}`}

Object.assign(H,{
 dtab:i=>{dtab=i;if(i==="all")ovLoad(false);else{ensureDash(dm);render()}},
 ovfull:async()=>{if(await askConfirm("This reads EVERY entry of all sections (1 read per entry; Firebase free limit is 50,000 reads per day for the whole team). Continue?"))ovLoad(true)},
 gobk:()=>nav("set"),
 ovclr:()=>{Object.assign(OF,{loc:"",cat:"",st:"",from:"",to:"",q:"",pre:"",len:3});render()},
 opr:()=>window.print(),
 ovex:()=>{const rows=ovRows(),locs=visLocs().filter(l=>!OF.loc||OF.loc===l.id),qt=v=>`"${String(v??"").replace(/"/g,'""')}"`,out=[];
  out.push(["Type","Serial starts with","Total","Resolved","Faulty","Pending","Fault %","Efficiency %",...locs.flatMap(l=>[l.menu+" - Total",l.menu+" - Faulty"])].map(qt).join(","));
  for(const cat of ["battery","charger"]){const g=new Map();rows.filter(x=>x.cat===cat).forEach(x=>{if(!g.has(x.pf))g.set(x.pf,[]);g.get(x.pf).push(x)});
   [...g].sort((a,b)=>b[1].length-a[1].length).forEach(([pf,a])=>{const t=agg(a);out.push([cat,pf,t.n,t.o,t.f,t.p,pct(t.f,t.n),pct(t.o,t.n),...locs.flatMap(l=>{const z=agg(a.filter(x=>x.loc===l.id));return [z.n,z.f]})].map(qt).join(","))})}
  dl(["\ufeff"+out.join("\n")],"overall_serial_series_"+today()+".csv","text/csv");toast("Exported");log("Exported overall analytics CSV",rows.length+" entries")},
 pd:i=>{const j=i.indexOf("|"),cat=i.slice(0,j),pf=i.slice(j+1),rows=ovRows().filter(x=>x.cat===cat&&x.pf===pf),T=agg(rows),m=$("#modal"),locs=visLocs().filter(l=>!OF.loc||OF.loc===l.id),
   bad=rows.filter(x=>x.st==="f"),iss=group(rows.map(x=>x.p),p=>p.reportedIssue||"").slice(0,8);
  m.innerHTML=`<div class="box" style="width:780px"><h2 style="color:var(--acc)">${CATL[cat]} · ${esc(pf)}</h2><p class="note">Serial numbers starting with <b>${esc(pf)}</b> (first ${OF.len} characters) · ${T.n} entries · current filters applied</p>
  <div class="cards">${kpi("Total",T.n)}${kpi("Resolved",T.o,"g2")}${kpi("Faulty",T.f,"r2")}${kpi("Pending / Hold",T.p,"o2")}${kpi("Fault %",pct(T.f,T.n)+"%","r2")}${kpi("Efficiency",pct(T.o,T.n)+"%","g2")}</div>
  <h3 class="sh">Location-wise</h3><div class="tw"><table><thead><tr><th>Location</th><th>Entries</th><th>Resolved</th><th>Faulty</th><th>Pending</th><th>Fault %</th></tr></thead><tbody>
  ${locs.map(l=>{const z=agg(rows.filter(x=>x.loc===l.id));return `<tr><td><b>${esc(l.menu)}</b></td><td>${z.n}</td><td>${z.o}</td><td>${z.f}</td><td>${z.p}</td><td>${z.n?`<span class="pf ${fcls(z.f/z.n*100)}">${pct(z.f,z.n)}%</span>`:"—"}</td></tr>`}).join("")}</tbody></table></div>
  <h3 class="sh">Top reported issues</h3><div class="tw"><table><thead><tr><th>Issue</th><th>Entries</th><th>Faulty</th></tr></thead><tbody>${iss.map(x=>`<tr><td class="w">${esc(x.k)}</td><td>${x.n}</td><td>${x.f}</td></tr>`).join("")||"<tr><td colspan=3>No data</td></tr>"}</tbody></table></div>
  <h3 class="sh">Faulty serial numbers (${bad.length})</h3><div>${bad.slice(0,80).map(x=>`<span class="chip" style="padding:4px 12px">${esc(x.sr||"(no serial)")} <small style="color:var(--mut)">${esc(locName(x.loc))}</small></span>`).join("")||"<small style='color:var(--mut)'>No faulty entries</small>"}${bad.length>80?`<small style="color:var(--mut)"> …and ${bad.length-80} more (use Export CSV / Status filter)</small>`:""}</div>
  <div class="row" style="margin-top:14px"><button class="gry" id="pkc">Close</button></div></div>`;
  m.onchange=null;m.oninput=null;m.classList.remove("hide");$("#pkc").onclick=()=>m.classList.add("hide")}
});
function bkWarn(){if(!isOwner())return "";const t=cfg.meta?.lastBackup,d=t?Math.floor((Date.now()-new Date(t))/864e5):null;
 return d===null||d>30?`<div class="alert">🛡 <b>Backup due.</b> ${d===null?"No full backup has been recorded yet.":"Last full backup was "+d+" days ago."} Download a Full Backup (JSON) at least once a month and keep a copy in Google Drive. <button class="gry" data-a="gobk" style="margin-left:8px">Go to Backup</button></div>`:""}
async function markBackup(){const iso=new Date().toISOString();try{await setDoc(doc(db,"config","meta"),{lastBackup:iso,lastBackupBy:me.name},{merge:true});cfg.meta={...(cfg.meta||{}),lastBackup:iso}}catch(_){}}
const dash=()=>bkWarn()+lowBanner()+modeBar()+(dtab==="all"?ovDash():dashLoc());


/* ===== INVENTORY (per location, live) ===== */
// Firestore: inventory/{locId}      = {items:{key:{name,added,lastQty,lastAt,lastBy}}}   (Admin / delegated "manage": import, restock)
//            inventory_use/{locId}  = {used:{key:n}}                                    (written automatically when entries are saved)
// Remaining stock = added - used.  Both docs are listened to (onSnapshot) so every screen updates in real time.
const INV={},INVU={},IF={q:"",st:"",sort:"name"},SUB=new Map();let invLoc="",invMode="add",INVP=null,LOWN=5;
const LOWDEF=20,lowTh=()=>{const v=Number(cfg.meta?.lowStock);return v>0?v:LOWDEF};
const pkey=s=>{const t=String(s||"").toLowerCase().replace(/[^a-z0-9]+/g,"_").replace(/^_+|_+$/g,"");if(t.length<=80)return t||"x";let h=0;for(const c of t)h=(h*31+c.charCodeAt(0))>>>0;return t.slice(0,70)+"_"+h.toString(36)};
const cleanName=s=>String(s??"").replace(/\s+/g," ").trim().slice(0,120);
const fmtQ=n=>Number.isInteger(n)?n:+Number(n).toFixed(2);
const baseName=s=>String(s||"").split(/\s[—–-]\s/)[0].trim();
const invKey=(loc,str)=>{const it=INV[loc]?.items||{},k=pkey(str);if(it[k])return k;const k2=pkey(baseName(str));return it[k2]?k2:""};
const remOf=(loc,key)=>{const I=INV[loc];return I&&I.items[key]?(+I.items[key].added||0)-(+I.used[key]||0):0};
const stOfRem=r=>r<=0?"out":r<lowTh()?"low":"ok";
const invRows=loc=>{const I=INV[loc];if(!I)return [];return Object.entries(I.items).map(([key,it])=>{const used=+I.used[key]||0,added=+it.added||0;return {key,loc,name:it.name||key,added,used,rem:added-used,lastQty:it.lastQty,lastAt:tsd(it.lastAt),lastBy:it.lastBy||""}})};
const lowList=()=>invLocs().flatMap(l=>invRows(l.id).filter(r=>r.rem<lowTh()).map(r=>({...r,locName:l.menu}))).sort((a,b)=>a.rem-b.rem);
const SORTS={name:(a,b)=>a.name.localeCompare(b.name),low:(a,b)=>a.rem-b.rem,used:(a,b)=>b.used-a.used,recent:(a,b)=>(b.lastAt||0)-(a.lastAt||0)};
/* parts used in an entry -> {partName: qty}. Mechanical / electrical parts carry the quantity typed in the form (partQty); component1/2 count 1 each */
const partsMap=p=>{const m={};for(const s of [...asArr(p.mechParts),...asArr(p.elecParts)]){const q=Math.max(1,+(p.partQty&&p.partQty[s])||1);m[s]=(m[s]||0)+q}
 for(const s of [p.component1,p.component2]){const t=String(s||"").trim();if(t)m[t]=(m[t]||0)+1}return m};
const cntParts=(loc,m)=>{const r={};for(const s in m){const key=invKey(loc,s);if(key)r[key]=(r[key]||0)+m[s]}return r};
const diffParts=(loc,a,b)=>{const x=cntParts(loc,a),y=cntParts(loc,b),r={};new Set([...Object.keys(x),...Object.keys(y)]).forEach(k=>{const d=(y[k]||0)-(x[k]||0);if(d)r[k]=d});return r};

/* live listeners (2 small docs per location; a change costs 1 read per open screen) */
function invListen(l){if(INVU[l])return INVU[l].ready;
 const st=INV[l]||(INV[l]={items:{},used:{},loaded:false,a:false,b:false});let r1,r2;
 const ready=Promise.all([new Promise(r=>r1=r),new Promise(r=>r2=r)]),fin=()=>{st.loaded=st.a&&st.b};
 const u1=onSnapshot(doc(db,"inventory",l),s=>{const d=s.exists()?s.data({serverTimestamps:"estimate"}):{};st.items=d.items||{};st.a=true;fin();r1();invTick()},()=>{st.a=true;fin();r1()});
 const u2=onSnapshot(doc(db,"inventory_use",l),s=>{st.used=s.exists()?(s.data().used||{}):{};st.b=true;fin();r2();invTick()},()=>{st.b=true;fin();r2()});
 INVU[l]={u:[u1,u2],ready};return ready}
function invStop(){for(const l in INVU){INVU[l].u.forEach(f=>{try{f()}catch(_){}});delete INVU[l]}for(const k in INV)delete INV[k]}
function invTick(){updBell();if(!me||!(view==="inv"||view==="dash"))return;
 const a=document.activeElement,ds=a&&a.dataset,key=ds&&(ds.inv==="q"?'[data-inv="q"]':ds.of==="q"||ds.of==="pre"?'[data-of="'+ds.of+'"]':a.id==="fq"?"#fq":""),pos=key?a.selectionStart:0;
 render();if(key){const n=document.querySelector(key);if(n){n.focus();try{n.setSelectionRange(pos,pos)}catch(_){}}}}
async function invLoadAll(){await Promise.all(invLocs().map(l=>invListen(l.id).catch(()=>{})));updBell()}
const invEnsure=async l=>{await invListen(l)};
function updBell(){publish()}
function lowModal(){const m=$("#modal"),L=lowList(),n=Math.min(LOWN,L.length);
 m.innerHTML=`<div class="box" style="width:660px"><h2 style="color:#b91c1c">🔔 Low stock alerts (${L.length})</h2><p class="note">Parts with less than ${lowTh()} in stock (live). Open the location’s Inventory and add the new quantity.</p>
 <div class="tw"><table><thead><tr><th>Location</th><th>Part</th><th>In stock</th></tr></thead><tbody>${L.slice(0,n).map(r=>`<tr><td>${esc(r.locName)}</td><td class="w">${esc(r.name)}</td><td><span class="pf ${r.rem<=0?"hi":"mid"}">${fmtQ(r.rem)}</span></td></tr>`).join("")||"<tr><td colspan=3>No alerts</td></tr>"}</tbody></table></div>
 ${L.length>n?`<div class="row" style="margin-top:10px"><button class="gry" id="lowmore">Load More (+${PGI(n)})</button><small style="color:var(--mut)">Showing ${n} of ${L.length}</small></div>`:""}
 <div class="row" style="margin-top:12px"><button id="lowgo">Open Inventory</button><button class="gry" id="pkc">Close</button></div></div>`;
 m.onchange=null;m.oninput=null;m.classList.remove("hide");$("#pkc").onclick=()=>{LOWN=5;m.classList.add("hide")};
 const mo=$("#lowmore");if(mo)mo.onclick=()=>{LOWN=n+PGI(n);lowModal()};
 $("#lowgo").onclick=()=>{LOWN=5;m.classList.add("hide");if(L[0])invLoc=L[0].loc;nav("inv")}}
function lowBanner(){const L=lowList();if(!L.length)return "";
 return `<div class="alert danger">📦 <b>${L.length} part(s) below ${lowTh()} in stock:</b> ${L.slice(0,5).map(r=>esc(r.name)+" ("+esc(r.locName)+": "+fmtQ(r.rem)+")").join(", ")}${L.length>5?" …":""} <button class="gry" data-a="gotoinv" style="margin-left:8px">Open Inventory</button></div>`}

/* auto deduction when an entry is saved (quantity typed in the form is deducted) */
async function saveEntry(k,id,data,oldRow,d){
 const loc=BASE[k].loc;try{await invEnsure(loc)}catch(_){}
 const I=INV[loc],has=!!I&&Object.keys(I.items).length>0,counted=oldRow?oldRow.invApplied===true:has;
 if(!oldRow&&has)data.invApplied=d.invApplied=true;
 const prev=SUB.has(id)?SUB.get(id):(oldRow?partsMap(oldRow):{}),nw=partsMap(d),delta=counted?diffParts(loc,prev,nw):{},ref=doc(db,BASE[k].col,id);
 if(!Object.keys(delta).length){await withTO(oldRow?updateDoc(ref,data):setDoc(ref,data));if(counted)SUB.set(id,nw);return}
 const b=writeBatch(db);if(oldRow)b.update(ref,data);else b.set(ref,data);
 const u={};for(const key in delta)u[key]=increment(delta[key]);
 b.set(doc(db,"inventory_use",loc),{used:u,updatedAt:serverTimestamp()},{merge:true});
 const before=SUB.has(id)?SUB.get(id):undefined;SUB.set(id,nw);
 try{await withTO(b.commit())}catch(e){if(e&&e.code!=="timeout"){if(before===undefined)SUB.delete(id);else SUB.set(id,before)}throw e}
 const lowNow=Object.keys(delta).filter(key=>delta[key]>0&&remOf(loc,key)<lowTh()).map(key=>(I.items[key]?.name||key)+" ("+fmtQ(remOf(loc,key))+")");
 if(lowNow.length)setTimeout(()=>toast("⚠ Low stock: "+lowNow.slice(0,3).join(", ")),1800)}

/* inventory managers write (stock screens update through the live listeners) */
async function invApply(loc,rows,mode){if(!invCan(loc,"e"))throw {code:"permission-denied"};await invEnsure(loc);const I=INV[loc],items={};
 for(const r of rows){const key=pkey(r.name),used=+I.used[key]||0,e={name:r.name,lastQty:r.qty,lastAt:serverTimestamp(),lastBy:me.name};e.added=mode==="set"?used+r.qty:increment(r.qty);items[key]=e}
 await withTO(setDoc(doc(db,"inventory",loc),{items,updatedAt:serverTimestamp()},{merge:true}),30000)}
async function invSetRem(loc,key,val){if(!invCan(loc,"e"))throw {code:"permission-denied"};const I=INV[loc],added=(+I.used[key]||0)+val;
 await withTO(setDoc(doc(db,"inventory",loc),{items:{[key]:{added,lastAt:serverTimestamp(),lastBy:me.name}},updatedAt:serverTimestamp()},{merge:true}))}

/* Excel */
let xlsxP=null;
const loadXLSX=()=>window.XLSX?Promise.resolve(window.XLSX):(xlsxP||(xlsxP=new Promise((res,rej)=>{const s=document.createElement("script");s.src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js";s.onload=()=>res(window.XLSX);s.onerror=()=>{xlsxP=null;rej(new Error("Excel library could not load. Check internet connection."))};document.head.appendChild(s)})));
function parseInv(aoa){let hr=-1,ci=0,cq=1;
 for(let r=0;r<Math.min(aoa.length,10);r++){const row=(aoa[r]||[]).map(x=>String(x).toLowerCase().trim());
  const a=row.findIndex(x=>/part|item|name|component|material|description/.test(x)),b=row.findIndex((x,i)=>i!==a&&/qty|quantity|stock|count|nos|pcs|balance/.test(x));
  if(a>=0&&b>=0){hr=r;ci=a;cq=b;break}}
 const map=new Map();let skipped=0;
 for(let r=hr+1;r<aoa.length;r++){const row=aoa[r]||[],name=cleanName(row[ci]),raw=String(row[cq]??"").replace(/,/g,"").trim(),q=Number(raw);
  if(!name&&!raw)continue;if(!name||raw===""||!isFinite(q)||q<0){skipped++;continue}
  const key=pkey(name),e=map.get(key);if(e)e.qty+=q;else map.set(key,{name,qty:q})}
 return {rows:[...map.values()],skipped}}
async function readInvFile(file){const X=await loadXLSX(),wb=X.read(await file.arrayBuffer(),{type:"array"}),ws=wb.Sheets[wb.SheetNames[0]];return parseInv(X.utils.sheet_to_json(ws,{header:1,defval:"",raw:true}))}
async function invPreview(file){const loc=invLoc;if(!invCan(loc,"e"))return;
 try{toast("Reading file…");const r=await readInvFile(file);if(!r.rows.length)return toast("No valid rows found. The file needs two columns: Part Name, Qty.");
  await invEnsure(loc);const I=INV[loc],nw=r.rows.filter(x=>!I.items[pkey(x.name)]).length,m=$("#modal"),set=invMode==="set";INVP={loc,mode:invMode,rows:r.rows};
  m.innerHTML=`<div class="box" style="width:700px"><h2 style="color:var(--acc)">⬆ Import preview — ${esc(locMenu(loc))}</h2>
  <p class="note"><b>${r.rows.length}</b> parts found · <b>${nw}</b> new · <b>${r.rows.length-nw}</b> already in inventory${r.skipped?` · <span style="color:#b91c1c">${r.skipped} row(s) skipped (missing name or invalid qty)</span>`:""}.<br>Mode: <b>${set?"Set stock to the quantity in the file":"Add the quantity to existing stock"}</b>.</p>
  <div class="tw" style="max-height:320px;overflow:auto"><table><thead><tr><th>Part Name</th><th>Qty in file</th><th>Now in stock</th><th>After import</th></tr></thead><tbody>${r.rows.slice(0,40).map(x=>{const key=pkey(x.name),cur=remOf(loc,key);return `<tr><td class="w">${esc(x.name)}${I.items[key]?"":' <span class="badge" style="background:#dcfce7;color:#166534">new</span>'}</td><td>${fmtQ(x.qty)}</td><td>${fmtQ(cur)}</td><td><b>${fmtQ(set?x.qty:cur+x.qty)}</b></td></tr>`}).join("")}</tbody></table></div>
  ${r.rows.length>40?`<p class="note">…and ${r.rows.length-40} more rows.</p>`:""}
  <div class="row" style="margin-top:14px"><button id="invok">Confirm Import</button><button class="gry" id="pkc">Cancel</button></div></div>`;
  m.onchange=null;m.oninput=null;m.classList.remove("hide");$("#pkc").onclick=()=>m.classList.add("hide");
  $("#invok").onclick=async()=>{const b=$("#invok");b.disabled=true;try{await invApply(INVP.loc,INVP.rows,INVP.mode);m.classList.add("hide");toast("Inventory updated ("+INVP.rows.length+" parts)");log("Inventory import",locMenu(INVP.loc)+": "+INVP.rows.length+" parts ("+INVP.mode+")")}catch(e){fail(e);b.disabled=false}}
 }catch(e){toast(e.message||"Could not read the file")}}
async function exportInv(locs){const aoa=l=>[["Part Name","Qty"],...invRows(l).sort(SORTS.name).map(r=>[r.name,fmtQ(r.rem)])],stamp=today();
 try{const X=await loadXLSX(),wb=X.utils.book_new(),used=new Set();
  locs.forEach(l=>{let nm=(locMenu(l)||l).replace(/[\\/?*\[\]:]/g," ").slice(0,28)||l,n=nm,i=2;while(used.has(n))n=nm+" "+(i++);used.add(n);X.utils.book_append_sheet(wb,X.utils.aoa_to_sheet(aoa(l)),n)});
  X.writeFile(wb,"inventory_"+(locs.length===1?(locMenu(locs[0])||locs[0]).replace(/[^A-Za-z0-9]+/g,"_"):"all_locations")+"_"+stamp+".xlsx")}
 catch(e){const l=locs[0],qt=v=>`"${String(v??"").replace(/"/g,'""')}"`;dl(["\ufeff"+aoa(l).map(r=>r.map(qt).join(",")).join("\n")],"inventory_"+l+"_"+stamp+".csv","text/csv");toast("Excel library unavailable — exported as CSV instead")}
 log("Inventory export",locs.map(l=>locMenu(l)).join(", "))}
async function invTemplate(loc){const L=LOCS.find(x=>x.id===loc),cm=L&&L.mods[1];let names=[];
 if(cm&&hasParts(cm))names=[...optsOf(cm,"mechParts"),...new Set(optsOf(cm,"elecParts").map(baseName))];
 const aoa=[["Part Name","Qty"],...(names.length?names:["Example Part"]).map(n=>[n,""])];
 try{const X=await loadXLSX(),wb=X.utils.book_new();X.utils.book_append_sheet(wb,X.utils.aoa_to_sheet(aoa),"Inventory");X.writeFile(wb,"inventory_template_"+(locMenu(loc)||loc).replace(/[^A-Za-z0-9]+/g,"_")+".xlsx")}
 catch(e){const qt=v=>`"${String(v??"").replace(/"/g,'""')}"`;dl(["\ufeff"+aoa.map(r=>r.map(qt).join(",")).join("\n")],"inventory_template.csv","text/csv")}}

/* views */
function invOne(loc){const l=LOCS.find(x=>x.id===loc),I=INV[loc],th=lowTh(),adm=invCan(loc,"e");if(!l)return "";if(!I||!I.loaded)return `<div class="sec">Loading inventory…</div>`;
 const all=invRows(loc),q=IF.q.toLowerCase(),rows=all.filter(r=>(!q||r.name.toLowerCase().includes(q))&&(!IF.st||stOfRem(r.rem)===IF.st)).sort(SORTS[IF.sort]||SORTS.name),
  lowA=all.filter(r=>r.rem<th),outA=all.filter(r=>r.rem<=0),qty=all.reduce((a,r)=>a+Math.max(r.rem,0),0),used=all.reduce((a,r)=>a+r.used,0),
  last=all.reduce((a,r)=>r.lastAt&&(!a||r.lastAt>a)?r.lastAt:a,null),mx=Math.max(1,...all.map(r=>r.added)),n=pgN("inv"),show=rows.slice(0,n),
  sb=r=>{const s=stOfRem(r.rem);return `<span class="pf ${s==="ok"?"lo":s==="low"?"mid":"hi"}">${s==="ok"?"In stock":s==="low"?"Low":"Out"}</span>`};
 return `<div class="row"><span style="flex:1;min-width:220px"><b style="font-size:16px;color:var(--acc)">📦 Inventory — ${l.ic} ${esc(l.menu)}</b> <span class="badge" style="background:#dcfce7;color:#166534">● Live</span><br><small style="color:var(--mut)">In stock = total added − parts used in repair entries. It reduces automatically (by the quantity entered) when an entry with parts is saved.${adm?"":" View only."}</small></span>
  ${adm?`<input type="file" id="invfile" accept=".xlsx,.xls,.csv" class="hide"><span style="display:flex;gap:8px;align-items:center;flex-wrap:wrap"><label style="margin:0">Import mode</label><select data-inv="mode" style="width:auto;margin:0;min-width:200px"><option value="add" ${invMode==="add"?"selected":""}>Add to existing stock</option><option value="set" ${invMode==="set"?"selected":""}>Set stock = file qty</option></select></span><button data-a="invimp">⬆ Import Excel</button><button class="gry" data-a="invtpl">⬇ Template</button><button class="gry" data-a="invadd">+ Add Part</button>`:""}
  <button class="grn" data-a="invexp">⬇ Export Excel</button></div>
 ${lowA.length?`<div class="alert danger">🔔 <b>${lowA.length} part(s) below ${th}:</b> ${lowA.sort((a,b)=>a.rem-b.rem).slice(0,5).map(r=>esc(r.name)+" ("+fmtQ(r.rem)+")").join(", ")}${lowA.length>5?" …":""}${adm?" — use <b>+ Restock</b> to add the new quantity.":" — please inform the Admin."}</div>`:""}
 <div class="cards">${kpi("Total Parts",all.length)}${kpi("Total Qty In Stock",fmtQ(qty),"g2")}${kpi("Low Stock (<"+th+")",lowA.length,"o2")}${kpi("Out of Stock",outA.length,"r2")}${kpi("Total Used (all time)",fmtQ(used))}${kpi("Last Updated",last?last.toLocaleDateString():"—")}</div>
 <div class="sec"><div class="row"><input data-inv="q" placeholder="Search part…" value="${esc(IF.q)}"><select data-inv="st"><option value="">All status</option><option value="low" ${IF.st==="low"?"selected":""}>Low stock only</option><option value="out" ${IF.st==="out"?"selected":""}>Out of stock only</option><option value="ok" ${IF.st==="ok"?"selected":""}>In stock only</option></select>
  <select data-inv="sort"><option value="name" ${IF.sort==="name"?"selected":""}>Sort: Name</option><option value="low" ${IF.sort==="low"?"selected":""}>Sort: Lowest stock</option><option value="used" ${IF.sort==="used"?"selected":""}>Sort: Most used</option><option value="recent" ${IF.sort==="recent"?"selected":""}>Sort: Recently updated</option></select>
  ${isAdmin()?`<span style="display:flex;gap:6px;align-items:center"><label style="margin:0">Alert below</label><input type="number" min="1" data-inv="low" value="${th}" style="width:80px;margin:0"></span>`:""}</div>
  <p class="note">Showing ${show.length} of ${rows.length} parts. Parts used in entries are matched by name (case/punctuation ignored; “Part — Position” also matches “Part”).</p>
  <div class="tw"><table><thead><tr><th>#</th><th>Part</th><th>In Stock (live)</th><th>Status</th><th></th><th>Total Added</th><th>Used</th><th>Last Import Qty</th><th>Last Updated</th><th>Updated By</th>${adm?`<th class="act">Actions</th>`:""}</tr></thead><tbody>
  ${show.map((r,i)=>`<tr><td>${i+1}</td><td class="w"><b>${esc(r.name)}</b></td><td style="font-size:15px;font-weight:700;color:${r.rem<=0?"#dc2626":r.rem<th?"#d97706":"#16a34a"}">${fmtQ(r.rem)}</td><td>${sb(r)}</td><td style="width:110px"><div class="bar"><i style="width:${Math.max(0,Math.min(100,r.rem/mx*100))}%;background:${r.rem<=0?"#dc2626":r.rem<th?"#d97706":"#16a34a"}"></i></div></td><td>${fmtQ(r.added)}</td><td>${fmtQ(r.used)}</td><td>${r.lastQty===undefined?"—":fmtQ(+r.lastQty)}</td><td>${r.lastAt?r.lastAt.toLocaleString():"—"}</td><td>${esc(r.lastBy||"—")}</td>${adm?`<td class="act"><button data-a="invrs" data-i="${r.key}" title="Add new quantity">+ Restock</button><button class="gry" data-a="invset" data-i="${r.key}" title="Edit / correct stock">✏️</button><button class="red" data-a="invdel" data-i="${r.key}" title="Delete part">🗑</button></td>`:""}</tr>`).join("")||`<tr><td colspan="${adm?11:10}">${all.length?"No parts match the filters":"No inventory yet."+(adm?" Import an Excel file (Part Name, Qty) or use + Add Part.":"")}</td></tr>`}</tbody></table></div>
  ${pgMore("inv",rows.length)}</div>`}
function invAll(vl){const th=lowTh(),D=vl.map(l=>{const a=invRows(l.id);return {l,n:a.length,qty:a.reduce((s,r)=>s+Math.max(r.rem,0),0),low:a.filter(r=>r.rem<th).length,out:a.filter(r=>r.rem<=0).length,used:a.reduce((s,r)=>s+r.used,0),last:a.reduce((s,r)=>r.lastAt&&(!s||r.lastAt>s)?r.lastAt:s,null)}}),L=lowList(),T=D.reduce((a,x)=>({n:a.n+x.n,qty:a.qty+x.qty,low:a.low+x.low,out:a.out+x.out,used:a.used+x.used}),{n:0,qty:0,low:0,out:0,used:0}),n=pgN("invlow");
 return `<div class="row"><span style="flex:1"><b style="font-size:16px;color:var(--acc)">🌐 Inventory — All Locations</b> <span class="badge" style="background:#dcfce7;color:#166534">● Live</span></span><button class="grn" data-a="invexpall">⬇ Export all (Excel)</button></div>
 <div class="cards">${kpi("Total Parts",T.n)}${kpi("Total Qty In Stock",fmtQ(T.qty),"g2")}${kpi("Low Stock (<"+th+")",T.low,"o2")}${kpi("Out of Stock",T.out,"r2")}${kpi("Total Used",fmtQ(T.used))}</div>
 <div class="sec"><h2>Location-wise Inventory</h2><div class="tw"><table><thead><tr><th>Location</th><th>Parts</th><th>Qty In Stock</th><th>Low</th><th>Out</th><th>Used</th><th>Last Updated</th><th></th></tr></thead><tbody>
 ${D.map(x=>`<tr><td><b>${x.l.ic} ${esc(x.l.menu)}</b></td><td>${x.n}</td><td><b>${fmtQ(x.qty)}</b></td><td>${x.low?`<span class="pf mid">${x.low}</span>`:0}</td><td>${x.out?`<span class="pf hi">${x.out}</span>`:0}</td><td>${fmtQ(x.used)}</td><td>${x.last?x.last.toLocaleString():"—"}</td><td><button class="gry" data-a="invloc" data-i="${x.l.id}">Open</button></td></tr>`).join("")}</tbody></table></div></div>
 <div class="sec"><h2>🔔 Low stock — all locations (${L.length})</h2><div class="tw"><table><thead><tr><th>Location</th><th>Part</th><th>In stock</th></tr></thead><tbody>${L.slice(0,n).map(r=>`<tr><td>${esc(r.locName)}</td><td class="w">${esc(r.name)}</td><td><span class="pf ${r.rem<=0?"hi":"mid"}">${fmtQ(r.rem)}</span></td></tr>`).join("")||"<tr><td colspan=3>Everything is above the alert level 👍</td></tr>"}</tbody></table></div>${pgMore("invlow",L.length)}</div>`}
function invView(){const vl=invLocs();if(!vl.length)return `<div class="sec"><h2>No inventory access</h2><p class="note">Ask the Admin to give you inventory access in Users → 🔐 Access.</p></div>`;
 if(invLoc==="__all"&&vl.length<2)invLoc="";if(invLoc!=="__all"&&!vl.some(l=>l.id===invLoc))invLoc=vl[0].id;
 return `<div class="tabs">${vl.map(l=>`<button class="${invLoc===l.id?"on":""}" data-a="invloc" data-i="${l.id}">${l.ic} ${esc(l.menu)}</button>`).join("")}${vl.length>1?`<button class="${invLoc==="__all"?"on":""}" data-a="invloc" data-i="__all">🌐 All Locations</button>`:""}</div>`+(invLoc==="__all"?invAll(vl):invOne(invLoc))}

Object.assign(H,{
 invloc:i=>{invLoc=i;PG={};render();invLoadAll().then(()=>{if(view==="inv")render()})},
 gotoinv:()=>nav("inv"),
 invimp:()=>{const f=$("#invfile");if(f)f.click()},
 invexp:()=>exportInv([invLoc]),
 invexpall:()=>exportInv(invLocs().map(l=>l.id)),
 invtpl:()=>invTemplate(invLoc),
 invadd:async()=>{if(!invCan(invLoc,"e"))return;const n=cleanName(await askPrompt("Part name:"));if(!n)return;const qs=await askPrompt("Quantity purchased / in stock now:","0",{num:true});if(qs===null)return;const q=Number(qs);if(!isFinite(q)||q<0)return toast("Enter a valid quantity.");
  try{await invApply(invLoc,[{name:n,qty:q}],"add");toast("Part saved");log("Inventory add part",locMenu(invLoc)+": "+n+" +"+q)}catch(e){fail(e)}},
 invrs:async i=>{if(!invCan(invLoc,"e"))return;const it=INV[invLoc]?.items[i];if(!it)return;const qs=await askPrompt('New quantity received for "'+it.name+'"\n(current stock: '+fmtQ(remOf(invLoc,i))+')\nIt will be ADDED to the current stock.',"",{num:true});if(qs===null||qs==="")return;const q=Number(qs);if(!isFinite(q)||q<=0)return toast("Enter a quantity greater than 0.");
  try{await invApply(invLoc,[{name:it.name,qty:q}],"add");toast("Stock added: "+it.name+" +"+fmtQ(q));log("Inventory restock",locMenu(invLoc)+": "+it.name+" +"+q)}catch(e){fail(e)}},
 invset:async i=>{if(!invCan(invLoc,"e"))return;const it=INV[invLoc]?.items[i];if(!it)return;const qs=await askPrompt('Correct the stock of "'+it.name+'" to (current: '+fmtQ(remOf(invLoc,i))+'):',fmtQ(remOf(invLoc,i)),{num:true});if(qs===null||qs==="")return;const q=Number(qs);if(!isFinite(q))return toast("Enter a valid number.");
  try{await invSetRem(invLoc,i,q);toast("Stock corrected");log("Inventory correction",locMenu(invLoc)+": "+it.name+" → "+q)}catch(e){fail(e)}},
 invdel:async i=>{if(!invCan(invLoc,"e"))return;const it=INV[invLoc]?.items[i];if(!it||!await askConfirm('Delete "'+it.name+'" from this location’s inventory?'))return;
  try{const b=writeBatch(db);b.update(doc(db,"inventory",invLoc),{["items."+i]:deleteField()});b.set(doc(db,"inventory_use",invLoc),{used:{[i]:deleteField()}},{merge:true});await withTO(b.commit());toast("Part deleted");log("Inventory delete part",locMenu(invLoc)+": "+it.name)}catch(e){fail(e)}}
});


/* ===== extra handlers: pager, serial search, user access, guards ===== */
Object.assign(H,{
 pgm:i=>{PG[i]=pgN(i)+PGI(pgN(i));render()},
 lm:()=>{const k=view,s=S[k];if(s.search)return;const inc=PGI(SHOW[k]);SHOW[k]+=inc;const l=applyF(k,s.rows,true);if(l.length<SHOW[k]&&s.more)loadMod(k,true,inc);else render()},
 dmore:()=>loadLogs(true),lmore:()=>loadLogs(true),
 uacc:i=>accModal(i),
 sq:async()=>{const k=curMod(),q=($("#sq")?.value||"").trim();if(!q)return H.sqc();const sf=serialKey(k);if(!sf)return toast("This section has no serial number column.");
  try{const qs=[q];if(q.toUpperCase()!==q)qs.push(q.toUpperCase());const seen=new Map();
   for(const t of qs){const r=await getDocs(query(collection(db,BASE[k].col),where(sf,">=",t),where(sf,"<=",t+"\uf8ff"),limit(20)));r.docs.forEach(d=>seen.set(d.id,{id:d.id,...d.data()}))}
   S[k].search={q,rows:[...seen.values()].sort((a,b)=>(tsd(b.createdAt)||0)-(tsd(a.createdAt)||0))};render()}catch(e){fail(e)}},
 sqc:()=>{const k=curMod();S[k].search=null;render()},
 sl:i=>{const mods=Object.keys(BASE).filter(k=>isAdmin()||canSet(k)),l=LOCS.find(x=>x.id===i);if(!l)return;const lm=l.mods.filter(k=>mods.includes(k));if(!lm.length)return;
  const cur=LOCS.find(x=>x.id===BASE[stm]?.loc),idx=Math.max(0,(cur?cur.mods:[]).indexOf(stm));stm=lm.includes(l.mods[idx])?l.mods[idx]:lm[0];render()},
 sm:i=>{if(!isAdmin()&&!canSet(i))return;stm=i;render()}
});
for(const n of ["oa","oe","od","ca","cr","cd","hf","rs"]){const f=H[n];H[n]=(...a)=>{if(!canSet(stm))return toast("You do not have access to edit this section.");return f(...a)}}
for(const n of ["sb","sr","sp","la","lr","ld","cu","dx","en","rpw","uacc"]){const f=H[n];if(f)H[n]=(...a)=>{if(!isAdmin())return;return f(...a)}}

/* verbatim safety copy on every delete (deterministic id, same batch) + Owner-only restore */
Object.assign(H,{
 del:async i=>{const k=view,p=findRow(k,i);if(!canMod(k,"d"))return;if(!await askConfirm("Permanently delete this entry? A verbatim safety copy is kept in the deleted-entries archive (only the Owner can restore it)."))return;
  try{const ref=doc(db,BASE[k].col,i),snap=await getDoc(ref),b=writeBatch(db);
   if(snap.exists())b.set(doc(db,"deleted_entries",BASE[k].col+"__"+i),{...snap.data(),_collection:BASE[k].col,_docId:i,_deletedBy:me.uid,_deletedByName:me.name,_deletedAt:serverTimestamp()});
   b.delete(ref);await withTO(b.commit());
   S[k].rows=S[k].rows.filter(x=>x.id!==i);if(S[k].search)S[k].search.rows=S[k].search.rows.filter(x=>x.id!==i);render();toast("Entry deleted (safety copy archived)");log("Deleted "+ft(k)+" entry",p?sid(k,p):i)}catch(e){fail(e)}},
 arcload:()=>arcLoad(false),arcmore:()=>arcLoad(true),
 arcrestore:async i=>{if(!isOwner())return;const r=ARC.rows[i];if(!r)return;const k=Object.keys(BASE).find(x=>BASE[x].col===r._collection);
  if(!await askConfirm("Restore this entry to "+(k?ft(k):r._collection)+"?"))return;
  try{const ref=doc(db,r._collection,r._docId);if((await getDoc(ref)).exists())return toast("This entry already exists.");
   const {id,_collection,_docId,_deletedBy,_deletedByName,_deletedAt,...data}=r;await withTO(setDoc(ref,data));
   if(k&&S[k])S[k].rows.unshift({id:r._docId,...data});toast("Entry restored");log("Restored deleted entry",(k?ft(k):r._collection)+": "+sidOf(data))}catch(e){fail(e)}}
});
const sidOf=d=>d.batterySrNo||d.assetSrNo||d.serialNo||d.iotImei||"(no serial)";
const ARC={rows:[],cur:null,more:false,loaded:false,busy:false};
async function arcLoad(more){if(!isOwner()||ARC.busy)return;ARC.busy=true;const n=more?PGI(ARC.rows.length):5;
 try{const qs=await getDocs(query(collection(db,"deleted_entries"),orderBy("_deletedAt","desc"),...(more&&ARC.cur?[startAfter(ARC.cur)]:[]),limit(n)));
  const arr=qs.docs.map(d=>({id:d.id,...d.data()}));ARC.rows=more?[...ARC.rows,...arr]:arr;ARC.cur=qs.docs[qs.docs.length-1]||ARC.cur;ARC.more=qs.docs.length===n;ARC.loaded=true}
 catch(e){fail(e)}finally{ARC.busy=false}render()}
function arcSec(){return `<div class="sec"><h2>🗃 Deleted entries archive (Owner only)</h2><p class="note">Every entry that anyone deletes is first copied here, word for word, and the copy can never be edited or removed. You can restore a deleted entry with one click.</p>
 ${ARC.loaded?`<div class="tw"><table><thead><tr><th>Deleted on</th><th>Section</th><th>Serial / ID</th><th>Deleted by</th><th></th></tr></thead><tbody>${ARC.rows.map((r,i)=>{const k=Object.keys(BASE).find(x=>BASE[x].col===r._collection);return `<tr><td>${tm(r._deletedAt)}</td><td>${esc(k?ft(k):r._collection)}</td><td>${esc(sidOf(r))}</td><td>${esc(r._deletedByName||"—")}</td><td><button class="gry" data-a="arcrestore" data-i="${i}">↩ Restore</button></td></tr>`}).join("")||"<tr><td colspan=5>Nothing has been deleted.</td></tr>"}</tbody></table></div>${ARC.more?`<div class="row" style="margin-top:10px"><button class="gry" data-a="arcmore">Load More (+${PGI(ARC.rows.length)})</button><small style="color:var(--mut)">Showing ${ARC.rows.length}</small></div>`:""}`:`<button class="gry" data-a="arcload">Show deleted entries</button>`}</div>`}

act.bell=lowModal;
const V={};host.events=V;host.onViewReady=()=>{if(me)render()};
V.onclick=e=>{const b=e.target.closest("[data-a]");if(b&&H[b.dataset.a])H[b.dataset.a](b.dataset.i,b)};
V.onchange=e=>{const t=e.target;PG={};
 if(t.dataset.of){OF[t.dataset.of]=t.dataset.of==="len"?+t.value:t.value;render()}
 else if(t.id==="invfile"){const f=t.files&&t.files[0];t.value="";if(f)invPreview(f)}
 else if(t.dataset.inv){const w=t.dataset.inv;if(w==="mode"){invMode=t.value;render()}else if(w==="low"){const v=Math.max(1,Math.floor(+t.value||20));setDoc(doc(db,"config","meta"),{lowStock:v},{merge:true}).then(()=>{cfg.meta={...(cfg.meta||{}),lowStock:v};updBell();render();toast("Alert level set to "+v)}).catch(fail)}else if(w!=="q"){IF[w]=t.value;render()}}
 else if(t.dataset.owin!==undefined){const v=+t.value;for(const k in BASE){WIN[k]=v;try{localStorage.setItem("win_"+k,v)}catch(_){}Object.assign(S[k],{rows:[],cur:null,more:false,loaded:false,full:false});SHOW[k]=5}ovLoad(false)}
 else if(t.dataset.win!==undefined){const k=curMod(),v=+t.value;WIN[k]=v;try{localStorage.setItem("win_"+k,v)}catch(_){}Object.assign(S[k],{rows:[],cur:null,more:false,loaded:false,full:false});SHOW[k]=5;render();loadMod(k,false,k===view?5:FETCH)}
 else if(t.dataset.f){const f=FL[curMod()];f[t.dataset.f]=t.value;if(t.dataset.f==="col")f.val="";render()}
 else if(t.dataset.dim){DIM[dm]=t.value;DALL[dm]=false;render()}
 else if(t.dataset.c==="loc"){updateDoc(doc(db,"users",t.dataset.i),{location:t.value}).then(()=>{const u=users.find(x=>x.id===t.dataset.i);if(u){u.location=t.value;log("Changed location",u.name+" → "+(locMenu(t.value)||"none"))}}).catch(fail)}else if(t.dataset.c==="ro"){updateDoc(doc(db,"users",t.dataset.i),{role:t.value}).then(()=>{const u=users.find(x=>x.id===t.dataset.i);if(u){u.role=t.value;log("Changed role",u.name+" → "+t.value)}}).catch(fail)}};
V.oninput=e=>{const t=e.target;PG={};if(t.dataset.inv==="q"){const p=t.selectionStart;IF.q=t.value;render();const n=document.querySelector('[data-inv="q"]');if(n){n.focus();try{n.setSelectionRange(p,p)}catch(_){}}return}
 if(t.dataset.of==="q"||t.dataset.of==="pre"){const key=t.dataset.of,p=t.selectionStart;OF[key]=t.value;render();const n=document.querySelector('[data-of="'+key+'"]');if(n){n.focus();try{n.setSelectionRange(p,p)}catch(_){}}return}
 if(t.id==="fq"){FL[curMod()].q=t.value;SHOW[curMod()]=5;const p=t.selectionStart;render();const n=$("#fq");n.focus();n.setSelectionRange(p,p)}};
V.onkeydown=e=>{if(e.key==="Enter"&&e.target.id==="sq")H.sq()};
