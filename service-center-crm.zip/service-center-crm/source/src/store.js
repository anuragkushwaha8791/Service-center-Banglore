// Tiny external store shared by the React shell and the CRM logic (no extra libraries).
export const UI={ver:0,boot:{state:"loading",msg:"Loading application…"},login:{msg:"",ok:false,busy:false},shell:null,toasts:[],dialog:null,theme:"light",warn:""};
const subs=new Set();
export const subscribe=f=>(subs.add(f),()=>subs.delete(f));
export const getVer=()=>UI.ver;
export const uiSet=p=>{Object.assign(UI,p);UI.ver++;subs.forEach(f=>f())};
// actions registered by the CRM logic, called by React components
export const act={};
// handle to the imperative areas (#view, #modal). React never renders children inside them.
export const host={view:null,onViewReady:null};
export const toastMsg=m=>{const id=Math.random().toString(36).slice(2);UI.toasts=[...UI.toasts,{id,m:String(m)}];uiSet({});setTimeout(()=>{UI.toasts=UI.toasts.filter(t=>t.id!==id);uiSet({})},3400)};
// in-app replacements for the browser's confirm() / prompt() pop-ups
export const askConfirm=(msg,o={})=>new Promise(res=>uiSet({dialog:{type:"confirm",msg:String(msg),res,ok:o.ok||"OK",danger:o.danger!==undefined?!!o.danger:(/delete|remove|reset/i.test(String(msg))&&!/restore/i.test(String(msg)))}}));
export const askPrompt=(msg,def="",o={})=>new Promise(res=>uiSet({dialog:{type:"prompt",msg:String(msg),def:def==null?"":String(def),res,ok:o.ok||"OK",num:!!o.num}}));
