import React from "react";
import {createRoot} from "react-dom/client";
import {App} from "./ui.jsx";
import {uiSet} from "./store.js";
createRoot(document.getElementById("root")).render(<App/>);
// the CRM logic (and the Firebase libraries it needs) load AFTER the splash screen is already visible
import("./logic.js").catch(e=>{console.error(e);uiSet({boot:{state:"loading",msg:"Could not load the server libraries. Please check your internet connection and reload.",err:true}})});
