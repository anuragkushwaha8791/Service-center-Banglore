// Build:  node build.mjs   -> writes ../index.html (one self-contained file: React + app inline, nothing else to host)
import {build} from "esbuild";import fs from "fs";import path from "path";import {fileURLToPath} from "url";
const here=path.dirname(fileURLToPath(import.meta.url));
const r=await build({entryPoints:[path.join(here,"src/main.jsx")],bundle:true,minify:true,format:"esm",target:"es2022",jsx:"automatic",write:false,legalComments:"none",
  external:["https://*"],define:{"process.env.NODE_ENV":'"production"'},logLevel:"info"});
let js=r.outputFiles[0].text.replace(/<\/script/gi,"<\\/script");
const css=fs.readFileSync(path.join(here,"src/styles.css"),"utf8").replace(/\/\*[\s\S]*?\*\//g,"").replace(/\n\s*\n/g,"\n");
let html=fs.readFileSync(path.join(here,"src/template.html"),"utf8");
html=html.replace("/*__CSS__*/",()=>css).replace("/*__JS__*/",()=>js);
const out=process.argv[2]||path.join(here,"..","index.html");fs.writeFileSync(out,html);
console.log("built",out,(html.length/1024).toFixed(0)+" KB");
